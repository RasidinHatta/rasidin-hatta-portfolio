@echo off
REM ============================================================
REM  HR Daily Attendance Leave Report — Daily Launcher
REM  Runs reports for all active databases in HR_REPORT_CONFIG
REM  Scheduled by Windows Task Scheduler at 08:00 daily
REM ============================================================

REM Change to the project directory
cd /d "C:\Users\USER\Desktop\dev\Project\email-automation\hr_leave_report"

REM Run the report
python app.py

REM Exit code is passed through automatically
