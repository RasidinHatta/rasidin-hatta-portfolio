# =============================================================================
# test_report.py - Quick Test Runner (Non-Scheduled, Direct Send)
# HR Daily Attendance Leave Report System
# =============================================================================
"""
Interactive test script for the full pipeline:
    SQL → Excel → PDF → Email

Run from the hr_leave_report/ directory:

    python test_report.py                        # Use today's date
    python test_report.py --date 2026-04-01      # Specific date
    python test_report.py --no-email             # Skip email, just check DB + PDF
    python test_report.py --no-db               # Skip DB, use sample data (dry run)
"""

import sys
import argparse
import traceback
from datetime import date, datetime
from pathlib import Path

# Force UTF-8 encoding for standard output to avoid Windows console crashes with emojis
if sys.stdout.encoding.lower() != 'utf-8':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except AttributeError:
        pass

# Ensure project root is in sys.path
sys.path.insert(0, str(Path(__file__).parent.resolve()))

from config import AppConfig
from utils.logger import setup_logger, get_logger
from utils.db import DatabaseManager, DatabaseError
from utils.excel_export import ExcelExporter
from utils.pdf_converter import PDFConverter, PDFConversionError
from utils.email_sender import EmailSender, EmailError

import pandas as pd

try:
    from rich.console import Console
    from rich.panel import Panel
    from rich.table import Table as RichTable
    from rich import print as rprint
    console = Console()
    RICH = True
except ImportError:
    RICH = False
    console = None


# =============================================================================
# Helpers
# =============================================================================

def divider(char="─", width=60):
    print(char * width)

def section(title: str):
    if RICH:
        console.rule(f"[bold cyan]{title}[/bold cyan]")
    else:
        divider()
        print(f"  {title}")
        divider()

def ok(msg):   print(f"  ✅  {msg}")
def fail(msg): print(f"  ❌  {msg}")
def info(msg): print(f"  ℹ️   {msg}")
def warn(msg): print(f"  ⚠️   {msg}")


# =============================================================================
# Step Functions
# =============================================================================

def step_sql(config: AppConfig, report_date: str) -> pd.DataFrame:
    """Step 1: Connect to SQL Server and execute stored procedure."""
    section("STEP 1 — SQL Server Connection & Stored Procedure")

    db = DatabaseManager(config.db)
    db.connect()

    info(f"Server   : {config.db.server}")
    info(f"Database : {config.db.database}")
    info(f"Auth     : {config.db.auth_mode}")

    try:
        srv = db.get_server_info()
        info(f"Version  : {srv['version']}")
        info(f"Time     : {srv['server_time']}")
    except Exception:
        pass

    print()
    info(f"Calling: EXEC dbo.sp_DailyAttendanceLeaveReport @ReportDate = '{report_date}'")
    df = db.execute_stored_procedure(report_date=report_date)
    db.disconnect()

    ok(f"Rows returned: {len(df)}")
    if not df.empty:
        info(f"Columns : {', '.join(df.columns.tolist())}")
        print()
        print("  Preview (first 5 rows):")
        print(df.head(5).to_string(index=False))
    else:
        warn("No rows returned. The email will still be sent with an empty report.")

    return df


def step_excel(config: AppConfig, df: pd.DataFrame, report_date: str, company_name: str) -> Path:
    """Step 2: Export DataFrame to styled Excel."""
    section("STEP 2 — Excel Export")

    exporter = ExcelExporter(config.report)
    excel_path = exporter.export(df, report_date, company_name=company_name, db_name=config.db.database)
    size_kb = excel_path.stat().st_size / 1024

    ok(f"Saved: {excel_path.name}  ({size_kb:.1f} KB)")
    return excel_path


def step_pdf(excel_path: Path) -> Path:
    """Step 3: Convert Excel → PDF (Excel deleted after conversion)."""
    section("STEP 3 — PDF Conversion")

    converter = PDFConverter(keep_excel=False)
    pdf_path = converter.convert(excel_path)
    size_kb = pdf_path.stat().st_size / 1024

    ok(f"PDF  : {pdf_path.name}  ({size_kb:.1f} KB)")
    return pdf_path


def step_email(config: AppConfig, df: pd.DataFrame, pdf_path: Path, report_date: str, company_name: str) -> None:
    """Step 4: Send email with PDF attachment only."""
    section("STEP 4 — Email")

    info(f"SMTP    : {config.email.smtp_server}:{config.email.smtp_port}")
    info(f"From    : {config.email.email_user}")
    info(f"To      : {', '.join(config.email.to_emails)}")
    if config.email.cc_emails:
        info(f"CC      : {', '.join(config.email.cc_emails)}")
    info(f"Attach  : {pdf_path.name if pdf_path else 'None'}")
    print()

    exporter = ExcelExporter(config.report)
    html_preview = ""
    if not df.empty:
        html_preview = exporter.generate_html_preview(
            df, max_rows=config.report.email_preview_rows, report_date=report_date
        )

    template_path = Path(__file__).parent / "templates" / "email_template.html"
    attachments = [pdf_path] if pdf_path else []

    mailer = EmailSender(config.email)
    mailer.send_report(
        report_date=report_date,
        attachments=attachments,
        html_preview=html_preview,
        row_count=len(df),
        test_mode=True,
        template_path=template_path,
        extra_context={"company_name": company_name},
    )
    ok("Email sent successfully!")


# =============================================================================
# Sample Data (--no-db dry-run mode)
# =============================================================================

def make_sample_data() -> pd.DataFrame:
    """Return a small sample DataFrame to test Excel/PDF/Email without a DB."""
    warn("Using SAMPLE DATA (--no-db mode). No SQL Server connection made.")
    return pd.DataFrame({
        "EmployeeID":   ["E001", "E002", "E003", "E004", "E005"],
        "EmployeeName": ["Ahmad Razif", "Siti Norhaida", "Lim Wei Keat",
                         "Ravi Subramaniam", "Nurul Ain"],
        "Department":   ["HR", "Finance", "IT", "Operations", "HR"],
        "Branch":       ["HQ", "HQ", "KL", "Penang", "HQ"],
        "AttendanceStatus": ["Present", "Annual Leave", "Present", "MC", "Present"],
        "CheckIn":      ["08:02", "-", "08:55", "-", "07:59"],
        "CheckOut":     ["17:15", "-", "18:00", "-", "17:05"],
        "Remarks":      ["", "AL Approved", "", "MC Certificate", ""],
    })


# =============================================================================
# Main
# =============================================================================

def main():
    parser = argparse.ArgumentParser(
        description="HR Leave Report — Test Runner (Direct Send)",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    parser.add_argument(
        "--date", "-d",
        metavar="YYYY-MM-DD",
        default=None,
        help="Report date (default: today)",
    )
    parser.add_argument(
        "--no-email",
        action="store_true",
        help="Skip email; only test SQL + Excel + PDF generation",
    )
    parser.add_argument(
        "--no-db",
        action="store_true",
        help="Skip SQL Server; use built-in sample data (dry run)",
    )
    # --excel flag removed: only PDF is attached to emails
    parser.add_argument(
        "--db",
        metavar="DATABASE",
        help="Override the default SQL database (e.g., MYPAY_OTHER)",
        default=None,
    )
    args = parser.parse_args()

    # Determine report date
    report_date = args.date or date.today().strftime("%Y-%m-%d")
    try:
        datetime.strptime(report_date, "%Y-%m-%d")
    except ValueError:
        print(f"❌ Invalid date format: '{report_date}'. Use YYYY-MM-DD.")
        sys.exit(1)

    # Load config
    config = AppConfig()

    from utils.db import DatabaseManager, DatabaseError
    db_manager = DatabaseManager(config.db)
    try:
        targets = db_manager.get_report_targets()
    except DatabaseError as e:
        print(f"❌ Failed to fetch database targets from {config.db.config_database}: {e}")
        sys.exit(1)
        
    if args.db:
        targets = [t for t in targets if t.database_name.lower() == args.db.lower()]
    
    if not targets:
        db_name = args.db or "Any"
        print(f"❌ No active target found for DB '{db_name}' in {config.db.config_database}")
        sys.exit(1)
        
    target = targets[0]
    config.db.database = target.database_name
    config.email.smtp_server = target.smtp_server
    config.email.smtp_port = target.smtp_port
    config.email.email_user = target.email_user
    config.email.email_password = target.email_password
    config.email.use_tls = target.email_use_tls
    config.email.to_emails = target.to_emails
    config.email.cc_emails = target.cc_emails

    # Setup logger (console + file)
    setup_logger(
        log_level=config.logging.log_level,
        logs_dir=config.logging.logs_dir,
        retention_days=config.logging.retention_days,
    )

    # -------------------------------------------------------
    # Banner
    # -------------------------------------------------------
    print()
    if RICH:
        console.print(Panel(
            f"[bold white]HR LEAVE REPORT — TEST RUN[/bold white]\n"
            f"[cyan]Date: {report_date}[/cyan]  |  "
            f"[yellow]Email: {'SKIP' if args.no_email else 'SEND'}[/yellow]  |  "
            f"[magenta]DB: {'SAMPLE' if args.no_db else 'LIVE'}[/magenta]",
            style="bold blue",
            expand=False,
        ))
    else:
        divider("═")
        print(f"  HR LEAVE REPORT — TEST RUN")
        print(f"  Date: {report_date}  |  Email: {'SKIP' if args.no_email else 'SEND'}  |  DB: {'SAMPLE' if args.no_db else 'LIVE'}")
        divider("═")
    print()

    start = datetime.now()
    df = pd.DataFrame()
    excel_path = None
    pdf_path = None

    # -------------------------------------------------------
    # Step 1: SQL / Sample Data
    # -------------------------------------------------------
    try:
        if args.no_db:
            df = make_sample_data()
        else:
            df = step_sql(config, report_date)
    except DatabaseError as e:
        fail(f"SQL Error: {e}")
        print(traceback.format_exc())
        sys.exit(1)
    except Exception as e:
        fail(f"Unexpected error in Step 1: {e}")
        print(traceback.format_exc())
        sys.exit(1)
    print()

    # -------------------------------------------------------
    # Step 2 & 3: Excel Export & PDF Conversion (Skip if no data)
    # -------------------------------------------------------
    if not df.empty:
        try:
            excel_path = step_excel(config, df, report_date, target.display_name)
        except Exception as e:
            fail(f"Excel Export Error: {e}")
            print(traceback.format_exc())
            sys.exit(1)
        print()

        try:
            pdf_path = step_pdf(excel_path)
        except PDFConversionError as e:
            fail(f"PDF Conversion Error: {e}")
            print(traceback.format_exc())
            sys.exit(1)
        except Exception as e:
            fail(f"Unexpected PDF error: {e}")
            print(traceback.format_exc())
            sys.exit(1)
        print()
    else:
        warn("Skipping Excel & PDF generation (No data).")
        print()

    # -------------------------------------------------------
    # Step 4: Email
    # -------------------------------------------------------
    if args.no_email:
        section("STEP 4 — Email")
        warn("Email skipped (--no-email flag).")
        if pdf_path:
            info(f"PDF is ready at: {pdf_path}")
        print()
    else:
        try:
            step_email(config, df, pdf_path, report_date, target.display_name)
        except EmailError as e:
            fail(f"Email Error: {e}")
            print(traceback.format_exc())
            sys.exit(1)
        except Exception as e:
            fail(f"Unexpected email error: {e}")
            print(traceback.format_exc())
            sys.exit(1)
        print()

    # -------------------------------------------------------
    # Summary
    # -------------------------------------------------------
    elapsed = (datetime.now() - start).total_seconds()
    section("SUMMARY")
    ok(f"Report date : {report_date}")
    ok(f"Time        : {datetime.now().strftime('%H:%M:%S')}")
    ok(f"Records     : {len(df)}")
    ok(f"PDF file    : {pdf_path.name if pdf_path else 'None'}")
    ok(f"Email       : {'Sent ✉️' if not args.no_email else 'Skipped'}")
    ok(f"Total time  : {elapsed:.1f}s")
    divider("═")
    print()


if __name__ == "__main__":
    main()
