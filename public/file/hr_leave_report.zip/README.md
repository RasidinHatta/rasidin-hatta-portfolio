# HR Daily Attendance & Leave Report — Automation System

> **Production-ready Python automation** for HR attendance and leave reporting.  
> Connects to Microsoft SQL Server, generates styled Excel reports, and emails them automatically on a schedule.

---

## 📁 Project Structure

```
hr_leave_report/
│
├── app.py                  ← Main entry point (CLI + scheduler)
├── config.py               ← Centralized configuration (reads .env)
├── .env                    ← Your environment variables (DO NOT commit)
├── .env.example            ← Template for .env
├── requirements.txt        ← Python dependencies
│
├── logs/                   ← Daily rotating log files
├── reports/                ← Generated Excel/ZIP reports
│
├── utils/
│   ├── __init__.py
│   ├── db.py               ← SQL Server connection + stored procedure
│   ├── excel_export.py     ← Styled Excel report generator
│   ├── email_sender.py     ← SMTP email dispatcher
│   ├── logger.py           ← Logging setup (file + console)
│   └── scheduler.py        ← Daily job scheduler
│
└── templates/
    └── email_template.html ← HTML email body template
```

---

## 🚀 Quick Start

### 1. Install Dependencies

```bash
cd hr_leave_report
pip install -r requirements.txt
```

### 2. Configure Environment

```bash
# Copy the example file
copy .env.example .env

# Edit .env with your actual settings
notepad .env
```

### 3. Run the System

**A. Interactive Test Runner (Direct Send)**
```bash
# Run for today's date (generates PDF and sends email)
python test_report.py

# Run for a specific date
python test_report.py --date 2026-04-01

# Send both PDF and Excel attachments
python test_report.py --excel

# Run without sending email (SQL + Excel + PDF only)
python test_report.py --no-email

# Dry run with sample data (no SQL Server required)
python test_report.py --no-db

# Run from a different database
python test_report.py --db MYPAY_COMPANY_B
```

**B. Production Application (`app.py`)**
```bash
# Run for today's date
python app.py

# Send both PDF and Excel attachments
python app.py --excel

# Run from a different database
python app.py --db MYPAY_COMPANY_B

# Validate configuration
python app.py --validate
```

---

## ⚙️ Configuration (`.env`)

| Variable | Description | Example / Default |
|---|---|---|
| `SQL_SERVER` | SQL Server host/instance | `MYSERVER\SQLEXPRESS` |
| `SQL_USERNAME` | SQL login username | `sa` |
| `SQL_PASSWORD` | SQL login password | `P@ssword123` |
| `SQL_AUTH_MODE` | Authentication mode (`sql` or `windows`) | `sql` |
| `SQL_DRIVER` | ODBC Driver version | `ODBC Driver 17 for SQL Server` |
| `SQL_RETRY_ATTEMPTS` | Number of connection retry attempts | `3` |
| `SQL_RETRY_DELAY` | Seconds to wait between retries | `5` |
| `SQL_CONFIG_DATABASE`| Central configuration database name | `HR_REPORT_CONFIG` |
| `DEFAULT_REPORT_DATE`| Default report date (leave empty for today) | |
| `FILTER_DEPARTMENT` | Department filter (leave empty for all) | |
| `FILTER_BRANCH` | Branch filter (leave empty for all) | |
| `EXCEL_PASSWORD` | Excel password protection (leave empty to disable) | |
| `ZIP_REPORT` | Compress output to ZIP (`True` / `False`) | `False` |
| `EMAIL_PREVIEW_ROWS` | Rows shown in email HTML body | `20` |
| `SCHEDULE_TIME` | Daily run time (24h format HH:MM) | `13:00` |
| `TIMEZONE` | Scheduler timezone | `Asia/Kuala_Lumpur` |
| `LOG_LEVEL` | Logging verbosity (`DEBUG`, `INFO`, `WARNING`, `ERROR`) | `INFO` |
| `LOG_RETENTION_DAYS` | Days to keep log files | `30` |
| `TEAMS_WEBHOOK_URL` | Optional: Microsoft Teams webhook | |
| `TELEGRAM_BOT_TOKEN`| Optional: Telegram bot token | |
| `TELEGRAM_CHAT_ID` | Optional: Telegram chat ID | |

---

## 🗄️ SQL Server Setup

### Windows Authentication

```env
SQL_AUTH_MODE=windows
SQL_DRIVER=ODBC Driver 17 for SQL Server
SQL_SERVER=MYSERVER
SQL_CONFIG_DATABASE=HR_REPORT_CONFIG
```

### SQL Authentication

```env
SQL_AUTH_MODE=sql
SQL_USERNAME=hr_report_user
SQL_PASSWORD=SecurePassword123
SQL_CONFIG_DATABASE=HR_REPORT_CONFIG
```

### Central Configuration Database Setup

The email automation system dynamically discovers which company/target databases to report on, what SMTP server to use, and who to email using the `HR_REPORT_CONFIG` database.

You must run the SQL script to create this structure:
```bash
# Run this once on your SQL Server
sqlcmd -S YOUR_SERVER -d master -i stored_procedure/setup_config_database.sql
```

The database contains a `dbo.report_targets` table:
```sql
CREATE TABLE dbo.report_targets (
    id              INT           IDENTITY(1,1) PRIMARY KEY,
    database_name   NVARCHAR(100) NOT NULL UNIQUE,   -- e.g. 'MYPAY_LCO'
    display_name    NVARCHAR(200) NOT NULL,           -- e.g. 'Company A (Main)'
    smtp_server     NVARCHAR(100) NOT NULL,
    smtp_port       INT           NOT NULL DEFAULT 587,
    email_user      NVARCHAR(100) NOT NULL,
    email_password  NVARCHAR(100) NOT NULL,
    email_use_tls   BIT           NOT NULL DEFAULT 1,
    to_emails       NVARCHAR(MAX) NOT NULL,           -- Comma-separated TO list
    cc_emails       NVARCHAR(MAX) NULL,               -- Comma-separated CC list
    is_active       BIT           NOT NULL DEFAULT 1
);
```

### Verify ODBC Driver

```powershell
# PowerShell — list installed ODBC drivers
Get-OdbcDriver | Select-Object Name
```

Download: [Microsoft ODBC Driver for SQL Server](https://docs.microsoft.com/en-us/sql/connect/odbc/download-odbc-driver-for-sql-server)

---

## 📊 Stored Procedure

The system automatically calls the report stored procedure against each target database:

```sql
EXEC dbo.sp_DailyAttendanceLeaveReport @ReportDate = '2026-04-01'
```

**Requirements:**
- The procedure must return at least one result set
- All column names become Excel headers
- `NULL` values are automatically replaced with empty strings

---

## 📧 Email Configuration (Centralized)

SMTP configurations are stored dynamically per-target in the configuration database (`dbo.report_targets`), allowing different branches or databases to have distinct sender accounts, mail servers, and recipient lists.

### Office 365 Dynamic Target Example
```sql
INSERT INTO dbo.report_targets 
    (database_name, display_name, smtp_server, smtp_port, email_user, email_password, email_use_tls, to_emails, cc_emails, is_active)
VALUES 
    ('MYPAY_LCO', 'Company LCO', 'smtp.office365.com', 587, 'hr@company.com', 'yourpassword', 1, 'recipient1@company.com', 'cc@company.com', 1);
```

### Gmail Dynamic Target Example (requires App Password)
```sql
INSERT INTO dbo.report_targets 
    (database_name, display_name, smtp_server, smtp_port, email_user, email_password, email_use_tls, to_emails, cc_emails, is_active)
VALUES 
    ('MYPAY_OTHER', 'Company Other', 'smtp.gmail.com', 587, 'sender@gmail.com', 'your_16_char_app_password', 1, 'recipient2@company.com', NULL, 1);
```

> **Gmail Note**: Enable 2FA → generate an [App Password](https://myaccount.google.com/apppasswords) for the email sender account.

---

## 🗓️ Scheduling

### Option A: Built-in Python Scheduler

```bash
# Runs indefinitely, executes at SCHEDULE_TIME daily
python app.py --schedule
```

### Option B: Windows Task Scheduler

```bash
# Print full setup instructions
python app.py --setup-task-scheduler
```

Quick command (run as Administrator):

```cmd
schtasks /create /tn "HRDailyAttendanceReport" ^
  /tr "python C:\path\to\hr_leave_report\app.py --run-now" ^
  /sc daily /st 07:00 /ru SYSTEM /f
```

---

## 📋 CLI Reference

### Production (`app.py`)
```text
usage: app.py [-h] [--date YYYY-MM-DD] [--schedule] [--no-email]
              [--validate] [--setup-task-scheduler]
              [--department DEPT] [--branch BRANCH] [--excel] [--db DATABASE]

Options:
  --date, -d       Report date (default: today)
  --schedule, -s   Start the daily scheduler loop
  --no-email       Generate report only, skip email sending
  --validate       Validate .env configuration
  --setup-task-scheduler  Print Windows Task Scheduler guide
  --department     Filter by department name
  --branch         Filter by branch name
  --excel          Include the Excel (.xlsx) file as an attachment in addition to the PDF
  --db             Override the default SQL database
```

### Test Runner (`test_report.py`)
```text
usage: test_report.py [-h] [--date YYYY-MM-DD] [--no-email] [--no-db] [--excel] [--db DATABASE]

Options:
  --date, -d       Report date (default: today)
  --no-email       Skip email; only test SQL + Excel + PDF generation
  --no-db          Skip SQL Server; use built-in sample data (dry run)
  --excel          Include the Excel (.xlsx) file as an attachment in addition to the PDF
  --db             Override the default SQL database
```

---

## 📂 Generated Files

| Type | Location | Example Filename |
|---|---|---|
| Excel Report | `reports/` | `Daily_Attendance_Leave_Report_20260401.xlsx` |
| ZIP Archive | `reports/` | `Daily_Attendance_Leave_Report_20260401.zip` |
| Log File | `logs/` | `hr_leave_report_20260401.log` |

---

## 🔔 Optional Notifications

### Microsoft Teams

1. Create an Incoming Webhook in Teams
2. Copy the webhook URL to `.env`:
   ```env
   TEAMS_WEBHOOK_URL=https://company.webhook.office.com/webhookb2/...
   ```

### Telegram

1. Create a bot via [@BotFather](https://t.me/BotFather)
2. Get your Chat ID via `getUpdates`
3. Add to `.env`:
   ```env
   TELEGRAM_BOT_TOKEN=1234567890:ABC...
   TELEGRAM_CHAT_ID=-100123456789
   ```

---

## 🗒️ Log Output Example

```
[INFO] ============================================================
[INFO] 🚀 Starting Daily Report Job | Date: 2026-04-01
[INFO] ============================================================
[INFO] [Step 1/4] 🔌 Connecting to SQL Server...
[INFO]    Server  : Microsoft SQL Server 2019
[INFO]    Database: MYPAY_LCO
[INFO] [Step 2/4] 📋 Executing stored procedure...
[INFO]    @ReportDate = '2026-04-01'
[INFO] ✅ Stored procedure executed. Rows retrieved: 142
[INFO] [Step 3/4] 📊 Exporting to Excel...
[INFO] ✅ Excel report saved: Daily_Attendance_Leave_Report_20260401.xlsx
[INFO] [Step 4/4] 📧 Sending email...
[INFO] ✅ Email sent successfully to 3 recipient(s).
[INFO] ✅ [SUCCESS] Daily report email sent successfully.
[INFO]    Date     : 2026-04-01
[INFO]    Records  : 142
[INFO]    File     : Daily_Attendance_Leave_Report_20260401.xlsx
[INFO]    Elapsed  : 8.3s
```

---

## 🔮 Future Expansion

| Feature | Status | Notes |
|---|---|---|
| Teams Notification | ✅ Ready | Set `TEAMS_WEBHOOK_URL` in `.env` |
| Telegram Notification | ✅ Ready | Set `TELEGRAM_BOT_TOKEN` in `.env` |
| ZIP Compression | ✅ Ready | Set `ZIP_REPORT=True` |
| Department Filter | ✅ Ready | CLI `--department` or `.env` |
| Branch Filter | ✅ Ready | CLI `--branch` or `.env` |
| WhatsApp Notification | 🔧 Planned | Twilio / Meta API integration |
| PDF Report | 🔧 Planned | ReportLab / WeasyPrint |
| REST API Trigger | 🔧 Planned | FastAPI endpoint |
| SSRS Integration | 🔧 Planned | SSRS REST API |
| Dashboard | 🔧 Planned | Power BI dataset push |

---

## 🛡️ Security Best Practices

- **Never commit `.env`** to version control. Add it to `.gitignore`.
- Use a **dedicated SQL account** with read-only access to `MYPAY_LCO`.
- Use **App Passwords** for Gmail (not your main password).
- Rotate credentials regularly.
- Review `logs/` periodically to monitor for failures.

---

## 📦 Requirements

- Python 3.8+
- Microsoft ODBC Driver 17 or 18 for SQL Server
- Network access to SQL Server and SMTP server

---

## 📝 License

Internal HR automation system. For authorized use only.
