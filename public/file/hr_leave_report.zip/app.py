# =============================================================================
# app.py - Application Entry Point
# HR Daily Attendance Leave Report System
# =============================================================================
"""
Usage:
    # Run immediately with today's date
    python app.py

    # Run with a specific date
    python app.py --date 2026-04-01

    # Start scheduler (runs daily at configured time)
    python app.py --schedule

    # Run now, skipping email (report generation only)
    python app.py --no-email

    # Validate configuration without sending anything
    python app.py --validate

    # Show Windows Task Scheduler setup guide
    python app.py --setup-task-scheduler

    # Filter by department
    python app.py --department "Engineering"

    # Filter by branch
    python app.py --branch "Kuala Lumpur"
"""

import argparse
import sys
import traceback
from datetime import date, datetime
from pathlib import Path

# Force UTF-8 encoding for standard output to avoid Windows console crashes with emojis
if sys.stdout.encoding.lower() != 'utf-8':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except AttributeError:
        pass

# Ensure project root is in sys.path
sys.path.insert(0, str(Path(__file__).parent.resolve()))

from config import AppConfig
from utils.logger import setup_logger, get_logger
from utils.db import DatabaseManager, DatabaseError
from utils.excel_export import ExcelExporter
from utils.pdf_converter import PDFConverter, PDFConversionError
from utils.email_sender import EmailSender, EmailError
from utils.scheduler import Scheduler, print_windows_task_scheduler_guide

try:
    from rich.console import Console
    from rich.panel import Panel
    from rich.text import Text
    RICH_AVAILABLE = True
    console = Console()
except ImportError:
    RICH_AVAILABLE = False
    console = None


# =============================================================================
# Banner
# =============================================================================

BANNER = """
╔══════════════════════════════════════════════════════════════╗
║         HR DAILY ATTENDANCE & LEAVE REPORT SYSTEM           ║
║                    Automation Engine v1.0                    ║
╚══════════════════════════════════════════════════════════════╝
"""


def print_banner() -> None:
    if RICH_AVAILABLE:
        console.print(Panel(
            "[bold cyan]HR DAILY ATTENDANCE & LEAVE REPORT SYSTEM[/bold cyan]\n"
            "[dim]Automation Engine v1.0[/dim]",
            style="bold blue",
            expand=False,
        ))
    else:
        print(BANNER)


# =============================================================================
# Core Report Job
# =============================================================================

def run_report_job(
    config: AppConfig,
    report_date: str,
    send_email: bool = True,
    department: str = None,
    branch: str = None,
    company_name: str = "",
) -> bool:
    """
    Execute the full report pipeline:
      1. Connect to SQL Server
      2. Execute stored procedure
      3. Export to Excel (intermediate step)
      4. Convert Excel → PDF (Excel deleted after conversion)
      5. Send email with PDF attachment only

    Args:
        config: Application configuration object.
        report_date: ISO date string (YYYY-MM-DD).
        send_email: If False, skip email sending.
        department: Optional department filter.
        branch: Optional branch filter.

    Returns:
        True if all steps succeeded, False if any step failed.
    """
    logger = get_logger()
    start_time = datetime.now()

    logger.info("=" * 60)
    logger.info(f"🚀 Starting Daily Report Job | Date: {report_date}")
    logger.info("=" * 60)

    df = None
    excel_path = None
    pdf_path = None

    # ------------------------------------------------------------------
    # Step 1: Database Connection & Stored Procedure Execution
    # ------------------------------------------------------------------
    try:
        logger.info("[Step 1/5] 🔌 Connecting to SQL Server...")
        db = DatabaseManager(config.db)
        db.connect()

        # Log server info
        try:
            info = db.get_server_info()
            logger.info(f"   Server  : {info['version']}")
            logger.info(f"   Database: {info['database']}")
            logger.info(f"   Time    : {info['server_time']}")
        except Exception:
            pass  # Non-critical

        logger.info("[Step 2/5] 📋 Executing stored procedure...")
        df = db.execute_stored_procedure(
            report_date=report_date,
            department=department,
            branch=branch,
        )
        db.disconnect()

        if df.empty:
            logger.warning("⚠️  No data returned from stored procedure for this date.")
            logger.info("   Empty report will still be generated and sent.")

    except DatabaseError as exc:
        logger.error(f"❌ [STEP 1-2 FAILED] Database error: {exc}")
        logger.error(traceback.format_exc())
        return False

    # ------------------------------------------------------------------
    # Step 3 & 4: Excel Export & PDF Conversion (Only if we have data)
    # ------------------------------------------------------------------
    if not df.empty:
        try:
            logger.info("[Step 3/5] 📊 Exporting to Excel...")
            exporter = ExcelExporter(config.report)
            excel_path = exporter.export(df, report_date, company_name=company_name, db_name=config.db.database)
            logger.info(f"   Saved: {excel_path}")

        except Exception as exc:
            logger.error(f"❌ [STEP 3 FAILED] Excel export error: {exc}")
            logger.error(traceback.format_exc())
            return False

        try:
            logger.info("[Step 4/5] 📄 Converting Excel → PDF...")
            converter = PDFConverter(keep_excel=False)  # delete .xlsx after PDF creation
            pdf_path = converter.convert(excel_path)
            logger.info(f"   PDF : {pdf_path}")

        except PDFConversionError as exc:
            logger.error(f"❌ [STEP 4 FAILED] PDF conversion error: {exc}")
            logger.error(traceback.format_exc())
            return False
    else:
        logger.info("[Step 3 & 4] ⏩ Skipped Excel/PDF generation (No data).")

    # ------------------------------------------------------------------
    # Step 5: Email Sending (PDF attachment)
    # ------------------------------------------------------------------
    if not send_email:
        logger.info("📧 Email sending skipped (--no-email flag).")
    else:
        try:
            logger.info("[Step 5/5] 📧 Sending email...")

            # Generate HTML preview from DataFrame
            html_preview = ""
            if df is not None and not df.empty:
                html_preview = exporter.generate_html_preview(
                    df,
                    max_rows=config.report.email_preview_rows,
                    report_date=report_date,
                )

            template_path = (
                Path(__file__).parent / "templates" / "email_template.html"
            )

            attachments = [pdf_path] if pdf_path else []

            mailer = EmailSender(config.email)
            mailer.send_report(
                report_date=report_date,
                attachments=attachments,
                html_preview=html_preview,
                row_count=len(df) if df is not None else 0,
                template_path=template_path,
                extra_context={"company_name": company_name},
            )
            
            if attachments:
                logger.info("[Step 5/5] 📧 Email sent with PDF attachment.")
            else:
                logger.info("[Step 5/5] 📧 Email sent without attachment (0 records).")

        except EmailError as exc:
            logger.error(f"❌ [STEP 5 FAILED] Email error: {exc}")
            logger.error(traceback.format_exc())
            return False

    # ------------------------------------------------------------------
    # Summary
    # ------------------------------------------------------------------
    elapsed = (datetime.now() - start_time).total_seconds()
    logger.info("=" * 60)
    logger.info(f"✅ [SUCCESS] Daily report email sent successfully.")
    logger.info(f"   Date     : {report_date}")
    logger.info(f"   Records  : {len(df) if df is not None else 0}")
    logger.info(f"   PDF      : {pdf_path.name if pdf_path else 'N/A'}")
    logger.info(f"   Elapsed  : {elapsed:.1f}s")
    logger.info("=" * 60)

    # Optional: Send Teams/Telegram notification
    _send_optional_notifications(config, report_date, len(df) if df is not None else 0)

    return True


# =============================================================================
# Optional Notification Integrations
# =============================================================================

def _send_optional_notifications(
    config: AppConfig, report_date: str, row_count: int
) -> None:
    """Send Teams and/or Telegram notifications if configured."""
    logger = get_logger()

    # Microsoft Teams
    if config.notifications.teams_enabled:
        try:
            _send_teams_notification(
                config.notifications.teams_webhook_url,
                report_date,
                row_count,
            )
        except Exception as exc:
            logger.warning(f"⚠️  Teams notification failed (non-critical): {exc}")

    # Telegram
    if config.notifications.telegram_enabled:
        try:
            _send_telegram_notification(
                config.notifications.telegram_bot_token,
                config.notifications.telegram_chat_id,
                report_date,
                row_count,
            )
        except Exception as exc:
            logger.warning(f"⚠️  Telegram notification failed (non-critical): {exc}")


def _send_teams_notification(webhook_url: str, report_date: str, row_count: int) -> None:
    """Send a Microsoft Teams Adaptive Card notification."""
    import requests
    import json

    logger = get_logger()
    logger.info("📣 Sending Microsoft Teams notification...")

    payload = {
        "@type": "MessageCard",
        "@context": "http://schema.org/extensions",
        "themeColor": "1F3864",
        "summary": f"HR Daily Report - {report_date}",
        "sections": [{
            "activityTitle": "📊 HR Daily Attendance & Leave Report",
            "activitySubtitle": f"Report Date: {report_date}",
            "facts": [
                {"name": "Total Records", "value": str(row_count)},
                {"name": "Generated At", "value": datetime.now().strftime("%Y-%m-%d %H:%M:%S")},
                {"name": "Status", "value": "✅ Sent Successfully"},
            ],
        }],
    }

    resp = requests.post(
        webhook_url,
        data=json.dumps(payload),
        headers={"Content-Type": "application/json"},
        timeout=10,
    )
    resp.raise_for_status()
    logger.info("✅ Teams notification sent.")


def _send_telegram_notification(
    bot_token: str, chat_id: str, report_date: str, row_count: int
) -> None:
    """Send a Telegram message via Bot API."""
    import requests

    logger = get_logger()
    logger.info("📱 Sending Telegram notification...")

    message = (
        f"📊 *HR Daily Attendance & Leave Report*\n\n"
        f"📅 Date: `{report_date}`\n"
        f"📋 Records: `{row_count}`\n"
        f"✅ Status: Sent Successfully\n"
        f"🕐 Generated: `{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}`"
    )

    url = f"https://api.telegram.org/bot{bot_token}/sendMessage"
    resp = requests.post(
        url,
        json={"chat_id": chat_id, "text": message, "parse_mode": "Markdown"},
        timeout=10,
    )
    resp.raise_for_status()
    logger.info("✅ Telegram notification sent.")


# =============================================================================
# CLI Argument Parser
# =============================================================================

def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="HR Daily Attendance & Leave Report Automation",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    parser.add_argument(
        "--date", "-d",
        metavar="YYYY-MM-DD",
        help="Report date (default: today)",
        default=None,
    )
    parser.add_argument(
        "--schedule", "-s",
        action="store_true",
        help="Start the scheduler (runs at configured time daily)",
    )
    parser.add_argument(
        "--no-email",
        action="store_true",
        help="Generate report only, skip email sending",
    )
    parser.add_argument(
        "--validate",
        action="store_true",
        help="Validate configuration and exit",
    )
    parser.add_argument(
        "--setup-task-scheduler",
        action="store_true",
        help="Print Windows Task Scheduler setup instructions and exit",
    )
    parser.add_argument(
        "--department",
        metavar="DEPT",
        help="Filter by department name",
        default=None,
    )
    parser.add_argument(
        "--branch",
        metavar="BRANCH",
        help="Filter by branch name",
        default=None,
    )
    # --excel flag removed: only PDF is attached to emails
    parser.add_argument(
        "--db",
        metavar="DATABASE",
        help="Override the default SQL database (e.g., MYPAY_OTHER)",
        default=None,
    )
    return parser


def run_all_reports(
    config: AppConfig,
    report_date: str,
    send_email: bool,
    department: str = None,
    branch: str = None,
    target_db: str = None
) -> bool:
    """Fetch targets from config DB and run report job for each."""
    logger = get_logger()
    db_manager = DatabaseManager(config.db)
    try:
        targets = db_manager.get_report_targets()
    except DatabaseError as exc:
        logger.error(f"❌ Failed to fetch database targets from {config.db.config_database}: {exc}")
        return False

    if target_db:
        targets = [t for t in targets if t.database_name.lower() == target_db.lower()]
        if not targets:
            logger.error(f"❌ Target database '{target_db}' not found or not active in config database.")
            return False

    if not targets:
        logger.warning("⚠️ No active report targets found in config database.")
        return True

    all_success = True
    for t in targets:
        # Override config for this iteration
        config.db.database = t.database_name
        config.email.smtp_server = t.smtp_server
        config.email.smtp_port = t.smtp_port
        config.email.email_user = t.email_user
        config.email.email_password = t.email_password
        config.email.use_tls = t.email_use_tls
        config.email.to_emails = t.to_emails
        config.email.cc_emails = t.cc_emails
        
        logger.info(f"\n" + "="*60)
        logger.info(f"▶️ Starting report for: {t.display_name} ({t.database_name})")
        logger.info("="*60)

        success = run_report_job(
            config=config,
            report_date=report_date,
            send_email=send_email,
            department=department,
            branch=branch,
            company_name=t.display_name,
        )
        if not success:
            all_success = False

    return all_success


# =============================================================================
# Main Entry Point
# =============================================================================

def main() -> None:
    parser = build_arg_parser()
    args = parser.parse_args()

    # Initialize config
    config = AppConfig()

    if args.db:
        config.db.database = args.db

    # Initialize logger
    setup_logger(
        name="hr_leave_report",
        log_level=config.logging.log_level,
        logs_dir=config.logging.logs_dir,
        retention_days=config.logging.retention_days,
    )
    logger = get_logger()

    print_banner()

    # ------------------------------------------------------------------
    # --setup-task-scheduler
    # ------------------------------------------------------------------
    if args.setup_task_scheduler:
        print_windows_task_scheduler_guide(
            script_path=str(Path(__file__).resolve()),
            python_path=sys.executable,
        )
        sys.exit(0)

    # ------------------------------------------------------------------
    # --validate
    # ------------------------------------------------------------------
    if args.validate:
        logger.info("🔍 Validating configuration...")
        try:
            config.validate_all()
            logger.info("✅ Global configuration is valid!")
            logger.info(f"   Config DB: {config.db.config_database}")
            logger.info(f"   SQL Server: {config.db.server}")
            logger.info(f"   Auth      : {config.db.auth_mode}")
            logger.info(f"   Schedule  : {config.scheduler.schedule_time} ({config.scheduler.timezone})")
            
            db_manager = DatabaseManager(config.db)
            targets = db_manager.get_report_targets()
            if targets:
                logger.info("\n✅ Configured Databases & Email Destinations:")
                for t in targets:
                    logger.info(f"   - {t.display_name} ({t.database_name})")
                    logger.info(f"     SMTP: {t.smtp_server}:{t.smtp_port} | From: {t.email_user}")
                    logger.info(f"     To  : {', '.join(t.to_emails) if t.to_emails else '(None)'}")
            else:
                logger.warning("   ⚠️ No active targets found in config database.")

        except ValueError as exc:
            logger.error(f"❌ Configuration error: {exc}")
            sys.exit(1)
        sys.exit(0)

    # ------------------------------------------------------------------
    # Validate config before running
    # ------------------------------------------------------------------
    try:
        config.validate_all()
    except ValueError as exc:
        logger.error(f"❌ Configuration error: {exc}")
        logger.error("   Please check your .env file and ensure all required values are set.")
        logger.error("   Run: python app.py --validate")
        sys.exit(1)

    # ------------------------------------------------------------------
    # Determine report date
    # ------------------------------------------------------------------
    if args.date:
        try:
            datetime.strptime(args.date, "%Y-%m-%d")
            report_date = args.date
        except ValueError:
            logger.error(f"❌ Invalid date format: '{args.date}'. Expected YYYY-MM-DD.")
            sys.exit(1)
    elif config.report.default_report_date:
        report_date = config.report.default_report_date
    else:
        report_date = date.today().strftime("%Y-%m-%d")

    # Resolve department/branch from args or config
    department = args.department or config.report.filter_department
    branch = args.branch or config.report.filter_branch

    # ------------------------------------------------------------------
    # --schedule: Start scheduler loop
    # ------------------------------------------------------------------
    if args.schedule:
        scheduler = Scheduler(config.scheduler)
        scheduler.set_job(
            lambda: run_all_reports(
                config=config,
                report_date=date.today().strftime("%Y-%m-%d"),
                send_email=not args.no_email,
                department=department,
                branch=branch,
                target_db=args.db
            )
        )
        scheduler.start()
        return

    # ------------------------------------------------------------------
    # Default: Run once immediately
    # ------------------------------------------------------------------
    success = run_all_reports(
        config=config,
        report_date=report_date,
        send_email=not args.no_email,
        department=department,
        branch=branch,
        target_db=args.db
    )
    sys.exit(0 if success else 1)


if __name__ == "__main__":
    main()
