# =============================================================================
# utils/logger.py - Centralized Logging Setup
# HR Daily Attendance Leave Report System
# =============================================================================

import logging
import sys
from datetime import datetime
from pathlib import Path
from logging.handlers import TimedRotatingFileHandler
from typing import Optional

try:
    from rich.logging import RichHandler
    from rich.console import Console
    RICH_AVAILABLE = True
except ImportError:
    RICH_AVAILABLE = False


def setup_logger(
    name: str = "hr_leave_report",
    log_level: str = "INFO",
    logs_dir: Optional[Path] = None,
    retention_days: int = 30,
) -> logging.Logger:
    """
    Set up and return the application logger.

    Features:
    - Console output with Rich formatting (if available) or plain text
    - Daily rotating log files in logs/ directory
    - Auto-cleanup of old log files based on retention_days

    Args:
        name: Logger name (used as log file prefix)
        log_level: Logging level string (DEBUG, INFO, WARNING, ERROR)
        logs_dir: Path to the logs directory
        retention_days: Number of days to retain log files

    Returns:
        Configured logging.Logger instance
    """
    logger = logging.getLogger(name)

    # Avoid adding duplicate handlers on re-import
    if logger.handlers:
        return logger

    level = getattr(logging, log_level.upper(), logging.INFO)
    logger.setLevel(level)

    log_format = "%(asctime)s | %(levelname)-8s | %(module)s | %(message)s"
    date_format = "%Y-%m-%d %H:%M:%S"

    # ------------------------------------------------------------------
    # Console Handler
    # ------------------------------------------------------------------
    if RICH_AVAILABLE:
        console_handler = RichHandler(
            console=Console(stderr=False),
            show_time=True,
            show_path=False,
            rich_tracebacks=True,
            markup=True,
        )
        console_handler.setFormatter(logging.Formatter("%(message)s"))
    else:
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setFormatter(logging.Formatter(log_format, datefmt=date_format))

    console_handler.setLevel(level)
    logger.addHandler(console_handler)

    # ------------------------------------------------------------------
    # File Handler (daily rotating)
    # ------------------------------------------------------------------
    if logs_dir:
        logs_dir = Path(logs_dir)
        logs_dir.mkdir(parents=True, exist_ok=True)

        today = datetime.now().strftime("%Y%m%d")
        log_file = logs_dir / f"{name}_{today}.log"

        file_handler = TimedRotatingFileHandler(
            filename=log_file,
            when="midnight",
            interval=1,
            backupCount=retention_days,
            encoding="utf-8",
        )
        file_handler.setFormatter(logging.Formatter(log_format, datefmt=date_format))
        file_handler.setLevel(level)
        logger.addHandler(file_handler)

        # Clean up old log files beyond retention period
        _cleanup_old_logs(logs_dir, name, retention_days)

    return logger


def _cleanup_old_logs(logs_dir: Path, prefix: str, retention_days: int) -> None:
    """Remove log files older than retention_days."""
    import time

    cutoff = time.time() - (retention_days * 86400)
    for log_file in logs_dir.glob(f"{prefix}_*.log*"):
        try:
            if log_file.stat().st_mtime < cutoff:
                log_file.unlink()
        except OSError:
            pass  # Skip files in use or already deleted


def get_logger(name: str = "hr_leave_report") -> logging.Logger:
    """
    Retrieve an existing logger by name.
    Call setup_logger() first in the application entry point.
    """
    return logging.getLogger(name)
