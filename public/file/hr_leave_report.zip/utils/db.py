# =============================================================================
# utils/db.py - SQL Server Database Manager
# HR Daily Attendance Leave Report System
# =============================================================================

import time
import pyodbc
import pandas as pd
from datetime import date, datetime
from typing import Optional, Tuple, Any
from contextlib import contextmanager

from utils.logger import get_logger

logger = get_logger()


class DatabaseError(Exception):
    """Custom exception for database-related errors."""
    pass


class DatabaseManager:
    """
    Manages SQL Server connection lifecycle and stored procedure execution.

    Features:
    - SQL and Windows Authentication support
    - Automatic retry with exponential backoff
    - Context manager support (with statement)
    - Parameterized stored procedure calls
    """

    def __init__(self, config):
        """
        Initialize DatabaseManager.

        Args:
            config: AppConfig.db (DatabaseConfig dataclass)
        """
        self._config = config
        self._connection: Optional[pyodbc.Connection] = None

    # ------------------------------------------------------------------
    # Connection Management
    # ------------------------------------------------------------------

    def connect(self) -> None:
        """
        Establish SQL Server connection with retry logic.

        Raises:
            DatabaseError: If all retry attempts fail.
        """
        last_error = None
        for attempt in range(1, self._config.retry_attempts + 1):
            try:
                logger.info(
                    f"[bold cyan]Connecting to SQL Server[/bold cyan] "
                    f"[{self._config.server}/{self._config.database}] "
                    f"(Attempt {attempt}/{self._config.retry_attempts})"
                    if self._is_rich_available() else
                    f"Connecting to SQL Server [{self._config.server}/{self._config.database}] "
                    f"(Attempt {attempt}/{self._config.retry_attempts})"
                )
                self._connection = pyodbc.connect(
                    self._config.connection_string,
                    timeout=30,
                )
                self._connection.setdecoding(pyodbc.SQL_CHAR, encoding="utf-8")
                self._connection.setdecoding(pyodbc.SQL_WCHAR, encoding="utf-8")
                self._connection.setencoding(encoding="utf-8")
                logger.info("✅ SQL Server connection established successfully.")
                return

            except pyodbc.Error as exc:
                last_error = exc
                logger.warning(
                    f"Connection attempt {attempt} failed: {exc}"
                )
                if attempt < self._config.retry_attempts:
                    delay = self._config.retry_delay * attempt  # exponential-ish backoff
                    logger.info(f"Retrying in {delay} seconds...")
                    time.sleep(delay)

        raise DatabaseError(
            f"Failed to connect to SQL Server after {self._config.retry_attempts} attempts. "
            f"Last error: {last_error}"
        )

    def disconnect(self) -> None:
        """Close the database connection if open."""
        if self._connection:
            try:
                self._connection.close()
                logger.info("🔌 SQL Server connection closed.")
            except pyodbc.Error as exc:
                logger.warning(f"Error while closing connection: {exc}")
            finally:
                self._connection = None

    def is_connected(self) -> bool:
        """Check if a database connection is active."""
        return self._connection is not None

    @contextmanager
    def connection_context(self):
        """
        Context manager for automatic connect/disconnect.

        Usage:
            with db_manager.connection_context():
                df = db_manager.execute_report(date)
        """
        try:
            self.connect()
            yield self
        finally:
            self.disconnect()

    # ------------------------------------------------------------------
    # Stored Procedure Execution
    # ------------------------------------------------------------------

    def ensure_stored_procedure_exists(self) -> None:
        """
        Check if dbo.sp_DailyAttendanceLeaveReport exists in the database.
        If not, read from stored_procedure/sp_DailyAttendanceLeaveReport.sql and execute it.
        """
        if not self._connection:
            raise DatabaseError("Not connected to database. Call connect() first.")

        try:
            cursor = self._connection.cursor()
            cursor.execute(
                "SELECT 1 FROM sys.procedures WHERE name = 'sp_DailyAttendanceLeaveReport' AND schema_id = SCHEMA_ID('dbo')"
            )
            exists = cursor.fetchone() is not None

            if not exists:
                logger.info("⚙️ Stored procedure not found. Creating dbo.sp_DailyAttendanceLeaveReport...")
                import re
                from pathlib import Path

                sql_path = Path(__file__).parent.parent / "stored_procedure" / "sp_DailyAttendanceLeaveReport.sql"
                if not sql_path.exists():
                    raise DatabaseError(f"SQL file not found at {sql_path}")

                with open(sql_path, "r", encoding="utf-8") as f:
                    sql_script = f.read()

                # pyodbc does not support 'GO' batch separator. Split script by GO.
                batches = re.split(r'(?i)^\s*GO\s*$', sql_script, flags=re.MULTILINE)
                for batch in batches:
                    if batch.strip():
                        cursor.execute(batch)

                self._connection.commit()
                logger.info("✅ Stored procedure created successfully.")
            
        except Exception as exc:
            self._connection.rollback()
            raise DatabaseError(f"Failed to ensure stored procedure exists: {exc}") from exc

    def execute_stored_procedure(
        self,
        report_date: Optional[str] = None,
        department: Optional[str] = None,
        branch: Optional[str] = None,
    ) -> pd.DataFrame:
        """
        Execute dbo.sp_DailyAttendanceLeaveReport and return results as DataFrame.

        Args:
            report_date: Date string in YYYY-MM-DD format. Defaults to today.
            department: Optional department filter.
            branch: Optional branch filter.

        Returns:
            pandas DataFrame containing the report data.

        Raises:
            DatabaseError: If the stored procedure fails.
        """
        if not self._connection:
            raise DatabaseError("Not connected to database. Call connect() first.")

        # Ensure the stored procedure exists before attempting to execute it
        self.ensure_stored_procedure_exists()

        if not report_date:
            report_date = date.today().strftime("%Y-%m-%d")

        logger.info(f"📋 Executing stored procedure: dbo.sp_DailyAttendanceLeaveReport")
        logger.info(f"   @ReportDate = '{report_date}'")

        try:
            cursor = self._connection.cursor()

            # Build the EXEC statement with parameters
            sql = "EXEC dbo.sp_DailyAttendanceLeaveReport @ReportDate = ?"
            params: Tuple[Any, ...] = (report_date,)

            # Optional department/branch parameters (extend if SP supports them)
            # Uncomment and adjust if the stored procedure accepts these params:
            # if department:
            #     sql += ", @Department = ?"
            #     params += (department,)
            # if branch:
            #     sql += ", @Branch = ?"
            #     params += (branch,)

            cursor.execute(sql, params)

            # Fetch column names from cursor description
            columns = [col[0] for col in cursor.description]
            rows = cursor.fetchall()

            logger.info(f"✅ Stored procedure executed. Rows retrieved: {len(rows)}")

            df = pd.DataFrame.from_records(rows, columns=columns)

            # Post-process: fill NaN values for clean export
            df = df.fillna("")

            return df

        except pyodbc.ProgrammingError as exc:
            raise DatabaseError(f"Stored procedure error: {exc}") from exc
        except pyodbc.Error as exc:
            raise DatabaseError(f"Database execution error: {exc}") from exc

    def get_server_info(self) -> dict:
        """Return SQL Server version and database metadata."""
        if not self._connection:
            raise DatabaseError("Not connected.")
        cursor = self._connection.cursor()
        cursor.execute(
            "SELECT @@VERSION AS Version, DB_NAME() AS DatabaseName, GETDATE() AS ServerTime"
        )
        row = cursor.fetchone()
        return {
            "version": row.Version.split("\n")[0] if row else "Unknown",
            "database": row.DatabaseName if row else "Unknown",
            "server_time": str(row.ServerTime) if row else "Unknown",
        }

    def get_report_targets(self) -> list:
        """
        Connect to config_database and fetch active report targets.
        Returns a list of ReportTarget dataclasses.
        """
        from config import ReportTarget
        original_db = self._config.database
        self._config.database = self._config.config_database
        
        targets = []
        try:
            with self.connection_context():
                cursor = self._connection.cursor()
                cursor.execute(
                    "SELECT database_name, display_name, "
                    "smtp_server, smtp_port, email_user, "
                    "COALESCE("
                    "  CONVERT(NVARCHAR(4000), DECRYPTBYPASSPHRASE(N'leave-management-report-config', email_password)), "
                    "  TRY_CONVERT(NVARCHAR(4000), email_password)"
                    ") AS email_password, "
                    "email_use_tls, to_emails, cc_emails "
                    "FROM dbo.report_targets WHERE is_active = 1 "
                    "ORDER BY id"
                )
                rows = cursor.fetchall()
                for row in rows:
                    to_emails = [e.strip() for e in row.to_emails.split(",")] if row.to_emails else []
                    cc_emails = [e.strip() for e in row.cc_emails.split(",")] if row.cc_emails else []
                    targets.append(ReportTarget(
                        database_name=row.database_name,
                        display_name=row.display_name,
                        smtp_server=row.smtp_server,
                        smtp_port=row.smtp_port,
                        email_user=row.email_user,
                        email_password=row.email_password,
                        email_use_tls=bool(row.email_use_tls),
                        to_emails=to_emails,
                        cc_emails=cc_emails
                    ))
            logger.info(f"Loaded {len(targets)} active target(s) from {self._config.config_database}.")
        except Exception as exc:
            raise DatabaseError(f"Failed to fetch report targets: {exc}") from exc
        finally:
            self._config.database = original_db
            
        return targets


    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _is_rich_available() -> bool:
        try:
            import rich  # noqa: F401
            return True
        except ImportError:
            return False

    def __enter__(self):
        self.connect()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.disconnect()
        return False  # Do not suppress exceptions
