# =============================================================================
# utils/pdf_converter.py - Excel → PDF Converter
# HR Daily Attendance Leave Report System
# =============================================================================
"""
Converts a styled .xlsx file to PDF.

Strategy (tried in order):
  1. win32com  — Uses Microsoft Excel COM automation.
               Best quality; requires Excel installed.
  2. LibreOffice headless — Requires LibreOffice installed.
               Good quality; cross-platform fallback.
  3. reportlab — Pure-Python fallback; renders raw data table.
               No Excel required; lower fidelity.
"""

import subprocess
import sys
import shutil
from pathlib import Path
from typing import Optional

from utils.logger import get_logger

logger = get_logger()


class PDFConversionError(Exception):
    """Raised when all PDF conversion methods fail."""
    pass


class PDFConverter:
    """
    Converts an Excel (.xlsx) file to PDF.

    Usage:
        converter = PDFConverter()
        pdf_path = converter.convert(excel_path)
    """

    def __init__(self, keep_excel: bool = False):
        """
        Args:
            keep_excel: If True, keep the .xlsx file alongside the PDF.
                        If False (default), delete .xlsx after successful PDF creation.
        """
        self._keep_excel = keep_excel

    # ------------------------------------------------------------------
    # Public Interface
    # ------------------------------------------------------------------

    def convert(self, excel_path: Path) -> Path:
        """
        Convert the given .xlsx file to .pdf in the same directory.

        Args:
            excel_path: Absolute path to the Excel file.

        Returns:
            Path to the generated PDF file.

        Raises:
            PDFConversionError: If all conversion methods fail.
        """
        excel_path = Path(excel_path)
        if not excel_path.exists():
            raise PDFConversionError(f"Excel file not found: {excel_path}")

        pdf_path = excel_path.with_suffix(".pdf")

        logger.info(f"📄 Converting Excel → PDF: {excel_path.name}")

        # Try each method in order of preference
        methods = [
            ("Excel COM (win32com)", self._convert_via_win32com),
            ("LibreOffice headless",  self._convert_via_libreoffice),
            ("ReportLab (fallback)",  self._convert_via_reportlab),
        ]

        last_error: Optional[Exception] = None
        for method_name, method_fn in methods:
            try:
                logger.info(f"   Trying: {method_name}...")
                method_fn(excel_path, pdf_path)
                if pdf_path.exists() and pdf_path.stat().st_size > 0:
                    logger.info(
                        f"✅ PDF created via {method_name}: {pdf_path.name} "
                        f"({pdf_path.stat().st_size / 1024:.1f} KB)"
                    )
                    if not self._keep_excel:
                        try:
                            excel_path.unlink()
                            logger.info(f"🗑️  Excel file removed: {excel_path.name}")
                        except OSError as e:
                            logger.warning(f"Could not delete Excel file: {e}")
                    return pdf_path
            except Exception as exc:
                logger.warning(f"   ⚠️  {method_name} failed: {exc}")
                last_error = exc
                continue

        raise PDFConversionError(
            f"All PDF conversion methods failed. Last error: {last_error}\n"
            "Please ensure Microsoft Excel or LibreOffice is installed, "
            "or install reportlab: pip install reportlab"
        )

    # ------------------------------------------------------------------
    # Method 1: Microsoft Excel via win32com (Windows only, best quality)
    # ------------------------------------------------------------------

    @staticmethod
    def _convert_via_win32com(excel_path: Path, pdf_path: Path) -> None:
        """
        Use Excel COM automation to save the workbook as PDF.
        Requires: pip install pywin32  +  Microsoft Excel installed.
        """
        try:
            import win32com.client as win32  # noqa
        except ImportError:
            raise RuntimeError(
                "pywin32 not installed. Run: pip install pywin32"
            )

        excel_app = None
        workbook = None
        try:
            excel_app = win32.DispatchEx("Excel.Application")
            excel_app.Visible = False
            excel_app.DisplayAlerts = False
            excel_app.ScreenUpdating = False

            # Prevent Excel from probing the printer during PDF export
            try:
                excel_app.PrintCommunication = False
            except Exception:
                pass

            workbook = excel_app.Workbooks.Open(str(excel_path.resolve()))

            # xlTypePDF = 0
            workbook.ExportAsFixedFormat(
                Type=0,                        # PDF
                Filename=str(pdf_path.resolve()),
                Quality=0,                     # xlQualityStandard
                IncludeDocProperties=True,
                IgnorePrintAreas=False,
                OpenAfterPublish=False,
            )
        finally:
            if workbook:
                try:
                    workbook.Close(SaveChanges=False)
                except Exception:
                    pass
            if excel_app:
                try:
                    excel_app.Quit()
                except Exception:
                    pass

    # ------------------------------------------------------------------
    # Method 2: LibreOffice headless (cross-platform fallback)
    # ------------------------------------------------------------------

    @staticmethod
    def _convert_via_libreoffice(excel_path: Path, pdf_path: Path) -> None:
        """
        Use LibreOffice in headless mode for conversion.
        Requires: LibreOffice installed and on PATH.
        """
        soffice = shutil.which("soffice") or shutil.which("libreoffice")
        if not soffice:
            raise RuntimeError("LibreOffice (soffice) not found on PATH.")

        output_dir = excel_path.parent
        result = subprocess.run(
            [
                soffice,
                "--headless",
                "--convert-to", "pdf",
                "--outdir", str(output_dir),
                str(excel_path),
            ],
            capture_output=True,
            text=True,
            timeout=60,
        )
        if result.returncode != 0:
            raise RuntimeError(
                f"LibreOffice conversion failed (exit {result.returncode}): "
                f"{result.stderr.strip()}"
            )

        # LibreOffice names the output file using the stem of the input
        lo_output = output_dir / (excel_path.stem + ".pdf")
        if lo_output.exists() and lo_output != pdf_path:
            lo_output.rename(pdf_path)

    # ------------------------------------------------------------------
    # Method 3: ReportLab pure-Python fallback (data table only)
    # ------------------------------------------------------------------

    @staticmethod
    def _convert_via_reportlab(excel_path: Path, pdf_path: Path) -> None:
        """
        Build a styled PDF directly from the Excel data using ReportLab.
        Requires: pip install reportlab openpyxl

        Note: This renders a data table — not a pixel-perfect Excel replica.
        """
        try:
            from reportlab.lib.pagesizes import A4, landscape
            from reportlab.lib import colors
            from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
            from reportlab.lib.units import cm
            from reportlab.platypus import (
                SimpleDocTemplate, Table, TableStyle,
                Paragraph, Spacer,
            )
            from reportlab.lib.enums import TA_CENTER
        except ImportError:
            raise RuntimeError(
                "reportlab not installed. Run: pip install reportlab"
            )

        import openpyxl

        # Read data from the Excel file (skip title rows, start at header row 4)
        wb = openpyxl.load_workbook(str(excel_path), data_only=True)
        ws = wb.active

        # Collect all rows starting from row 4 (header) onward
        all_rows = list(ws.iter_rows(min_row=4, values_only=True))
        if not all_rows:
            raise RuntimeError("No data found in Excel file for PDF conversion.")

        # Build table data (header + data rows), replacing None with ""
        table_data = [
            [str(cell) if cell is not None else "" for cell in row]
            for row in all_rows
        ]
        headers = table_data[0]
        data_rows = table_data[1:]

        # Auto column widths (distribute evenly across A4 landscape)
        page_width = landscape(A4)[0] - 2 * cm
        num_cols = len(headers)
        col_width = page_width / num_cols

        # Build the table
        table = Table(
            [headers] + data_rows,
            colWidths=[col_width] * num_cols,
            repeatRows=1,
        )
        table.setStyle(TableStyle([
            # Header
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1F3864")),
            ("TEXTCOLOR",  (0, 0), (-1, 0), colors.white),
            ("FONTNAME",   (0, 0), (-1, 0), "Helvetica-Bold"),
            ("FONTSIZE",   (0, 0), (-1, 0), 8),
            ("ALIGN",      (0, 0), (-1, 0), "CENTER"),
            ("BOTTOMPADDING", (0, 0), (-1, 0), 6),
            ("TOPPADDING",    (0, 0), (-1, 0), 6),
            # Data rows
            ("FONTNAME",   (0, 1), (-1, -1), "Helvetica"),
            ("FONTSIZE",   (0, 1), (-1, -1), 7),
            ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#EBF0FA")]),
            ("ALIGN",      (0, 1), (-1, -1), "LEFT"),
            ("VALIGN",     (0, 0), (-1, -1), "MIDDLE"),
            ("TOPPADDING",    (0, 1), (-1, -1), 3),
            ("BOTTOMPADDING", (0, 1), (-1, -1), 3),
            # Grid
            ("GRID",       (0, 0), (-1, -1), 0.3, colors.HexColor("#BDD7EE")),
            ("LINEBELOW",  (0, 0), (-1, 0),  1.0, colors.HexColor("#1F3864")),
        ]))

        # Styles
        styles = getSampleStyleSheet()
        title_style = ParagraphStyle(
            "ReportTitle",
            parent=styles["Title"],
            fontSize=14,
            textColor=colors.HexColor("#1F3864"),
            alignment=TA_CENTER,
            spaceAfter=4,
        )
        subtitle_style = ParagraphStyle(
            "ReportSubtitle",
            parent=styles["Normal"],
            fontSize=9,
            textColor=colors.HexColor("#555555"),
            alignment=TA_CENTER,
            spaceAfter=10,
        )

        from datetime import date as _date
        today = _date.today().strftime("%d %B %Y")

        elements = [
            Paragraph("HR Daily Attendance & Leave Report", title_style),
            Paragraph(f"Generated on {today}  |  {len(data_rows)} records", subtitle_style),
            Spacer(1, 0.3 * cm),
            table,
        ]

        doc = SimpleDocTemplate(
            str(pdf_path),
            pagesize=landscape(A4),
            leftMargin=1 * cm,
            rightMargin=1 * cm,
            topMargin=1.5 * cm,
            bottomMargin=1 * cm,
        )
        doc.build(elements)
