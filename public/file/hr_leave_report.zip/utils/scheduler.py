# =============================================================================
# utils/scheduler.py - Job Scheduler
# HR Daily Attendance Leave Report System
# =============================================================================

import signal
import sys
import time
from datetime import datetime
from typing import Callable, Optional

try:
    import schedule
    SCHEDULE_AVAILABLE = True
except ImportError:
    SCHEDULE_AVAILABLE = False

try:
    import pytz
    PYTZ_AVAILABLE = True
except ImportError:
    PYTZ_AVAILABLE = False

from utils.logger import get_logger

logger = get_logger()


class Scheduler:
    """
    Wraps the `schedule` library to run the daily report job at a configured time.

    Features:
    - Configurable run time (HH:MM, 24-hour)
    - Timezone-aware execution
    - Graceful shutdown on SIGINT / SIGTERM
    - Manual trigger support (--run-now CLI flag)
    - Health heartbeat logging every hour
    """

    def __init__(self, config):
        """
        Args:
            config: AppConfig.scheduler (SchedulerConfig dataclass)
        """
        self._config = config
        self._job_func: Optional[Callable] = None
        self._running = False

    # ------------------------------------------------------------------
    # Public Interface
    # ------------------------------------------------------------------

    def set_job(self, job_func: Callable) -> None:
        """Register the job function to be called on schedule."""
        self._job_func = job_func

    def run_now(self) -> None:
        """Execute the job immediately (bypass schedule)."""
        if not self._job_func:
            raise RuntimeError("No job registered. Call set_job() first.")
        logger.info("▶️  Running job immediately (manual trigger)...")
        self._job_func()

    def start(self) -> None:
        """
        Start the scheduler loop.
        The loop blocks until a SIGINT or SIGTERM signal is received.
        """
        if not SCHEDULE_AVAILABLE:
            raise ImportError(
                "The 'schedule' package is not installed. "
                "Run: pip install schedule"
            )
        if not self._job_func:
            raise RuntimeError("No job registered. Call set_job() first.")

        run_time = self._config.schedule_time
        tz = self._config.timezone

        logger.info("=" * 60)
        logger.info("🕐 HR Leave Report Scheduler Started")
        logger.info(f"   Scheduled time : {run_time} ({tz})")
        logger.info(f"   Next run       : {self._get_next_run_display(run_time)}")
        logger.info("   Press Ctrl+C to stop.")
        logger.info("=" * 60)

        # Register the daily job
        schedule.every().day.at(run_time).do(self._job_wrapper)

        # Register hourly heartbeat
        schedule.every().hour.do(self._heartbeat)

        # Graceful shutdown handlers
        signal.signal(signal.SIGINT, self._shutdown_handler)
        signal.signal(signal.SIGTERM, self._shutdown_handler)

        self._running = True
        while self._running:
            schedule.run_pending()
            time.sleep(30)  # Check every 30 seconds

        logger.info("🛑 Scheduler stopped.")

    # ------------------------------------------------------------------
    # Internal Helpers
    # ------------------------------------------------------------------

    def _job_wrapper(self) -> None:
        """Wraps the job function to catch and log exceptions."""
        logger.info("=" * 60)
        logger.info(f"⏰ Scheduled job triggered at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        logger.info("=" * 60)
        try:
            self._job_func()
        except Exception as exc:
            logger.error(f"❌ Scheduled job failed: {exc}", exc_info=True)

    def _heartbeat(self) -> None:
        """Log a periodic heartbeat to confirm the scheduler is alive."""
        if SCHEDULE_AVAILABLE:
            next_run = schedule.next_run()
            next_run_str = next_run.strftime("%Y-%m-%d %H:%M:%S") if next_run else "Unknown"
        else:
            next_run_str = "Unknown"
        logger.info(
            f"💓 Scheduler heartbeat | Current time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} "
            f"| Next run: {next_run_str}"
        )

    def _shutdown_handler(self, signum, frame) -> None:
        """Handle OS shutdown signals gracefully."""
        logger.info(f"\n🛑 Shutdown signal received (signal {signum}). Stopping scheduler...")
        self._running = False

    def _get_next_run_display(self, run_time: str) -> str:
        """Calculate and format the next scheduled run time."""
        try:
            now = datetime.now()
            scheduled_hour, scheduled_minute = map(int, run_time.split(":"))
            next_run = now.replace(hour=scheduled_hour, minute=scheduled_minute, second=0)
            if next_run <= now:
                from datetime import timedelta
                next_run += timedelta(days=1)
            return next_run.strftime("%Y-%m-%d %H:%M")
        except Exception:
            return "Unknown"


# =============================================================================
# Windows Task Scheduler Helper
# =============================================================================

def print_windows_task_scheduler_guide(script_path: str, python_path: str = "python") -> None:
    """
    Print instructions for setting up the report as a Windows Task Scheduler task.

    Args:
        script_path: Absolute path to app.py
        python_path: Path to the Python interpreter
    """
    schtasks_cmd = (
        f'schtasks /create /tn "HRDailyAttendanceReport" '
        f'/tr "{python_path} {script_path} --run-now" '
        f'/sc daily /st 07:00 /ru SYSTEM /f'
    )

    print("\n" + "=" * 70)
    print("  WINDOWS TASK SCHEDULER SETUP GUIDE")
    print("=" * 70)
    print("\nOption 1: Command Prompt (Run as Administrator)")
    print("-" * 50)
    print(schtasks_cmd)
    print("\nOption 2: Manual GUI Setup")
    print("-" * 50)
    print("1. Open Task Scheduler (taskschd.msc)")
    print("2. Click 'Create Basic Task'")
    print("3. Name: 'HR Daily Attendance Report'")
    print("4. Trigger: Daily at 7:00 AM")
    print(f"5. Action: Start a Program → {python_path}")
    print(f"   Arguments: {script_path} --run-now")
    print("6. Enable 'Run whether user is logged on or not'")
    print("7. Check 'Run with highest privileges'")
    print("\nOption 3: PowerShell (Run as Administrator)")
    print("-" * 50)
    print(f"""$action = New-ScheduledTaskAction -Execute "{python_path}" -Argument "{script_path} --run-now"
$trigger = New-ScheduledTaskTrigger -Daily -At 7am
$settings = New-ScheduledTaskSettingsSet -ExecutionTimeLimit (New-TimeSpan -Hours 1)
Register-ScheduledTask -Action $action -Trigger $trigger -Settings $settings \\
    -TaskName "HRDailyAttendanceReport" -RunLevel Highest -Force""")
    print("=" * 70 + "\n")
