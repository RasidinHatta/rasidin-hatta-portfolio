# =============================================================================
# utils/email_sender.py - SMTP Email Dispatcher
# HR Daily Attendance Leave Report System
# =============================================================================

import smtplib
import mimetypes
from html import escape
from datetime import datetime
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
from pathlib import Path
from typing import List, Optional

from utils.logger import get_logger

logger = get_logger()


class EmailError(Exception):
    """Custom exception for email-related errors."""
    pass


class EmailSender:
    """
    SMTP email dispatcher with HTML body, attachments, and CC support.

    Supports:
    - Office 365 (smtp.office365.com:587)
    - Gmail     (smtp.gmail.com:587)
    - Any STARTTLS-compatible SMTP server

    Features:
    - Multiple TO recipients
    - Multiple CC recipients
    - HTML email body with inline report preview
    - File attachment (Excel or ZIP)
    - Retry on transient SMTP errors
    """

    def __init__(self, config):
        """
        Args:
            config: AppConfig.email (EmailConfig dataclass)
        """
        self._config = config

    # ------------------------------------------------------------------
    # Public Interface
    # ------------------------------------------------------------------

    def send_report(
        self,
        report_date: str,
        attachments: List[Path],
        html_preview: str = "",
        row_count: int = 0,
        test_mode: bool = False,
        extra_context: Optional[dict] = None,
        template_path: Optional[Path] = None,
    ) -> bool:
        """
        Build and send the daily report email.

        Args:
            report_date: Report date string (YYYY-MM-DD).
            attachments: List of paths to Excel/PDF/ZIP attachments.
            html_preview: Optional HTML table preview for the email body.
            row_count: Number of records in the report.
            extra_context: Optional dict of template variables.
            template_path: Optional path to HTML email template file.

        Returns:
            True if email was sent successfully, False otherwise.
        """
        formatted_date = datetime.strptime(report_date, "%Y-%m-%d").strftime("%d %B %Y")
        subject = f"Daily Attendance Leave Report - {formatted_date}"

        logger.info(f"📧 Preparing email: {subject}")
        logger.info(f"   To: {', '.join(self._config.to_emails)}")
        if self._config.cc_emails:
            logger.info(f"   CC: {', '.join(self._config.cc_emails)}")

        # Build HTML body
        html_body = self._build_html_body(
            report_date=report_date,
            formatted_date=formatted_date,
            html_preview=html_preview,
            row_count=row_count,
            attachments=attachments,
            test_mode=test_mode,
            template_path=template_path,
            extra_context=extra_context or {},
        )

        # Compose the MIME message
        msg = self._compose_message(
            subject=subject,
            html_body=html_body,
            attachments=attachments,
        )

        # Send via SMTP
        return self._send_smtp(msg)

    # ------------------------------------------------------------------
    # Message Composition
    # ------------------------------------------------------------------

    def _compose_message(
        self,
        subject: str,
        html_body: str,
        attachments: List[Path],
    ) -> MIMEMultipart:
        """Build the MIMEMultipart email message."""
        msg = MIMEMultipart("mixed")
        msg["From"] = self._config.email_user
        msg["To"] = ", ".join(self._config.to_emails)
        msg["Subject"] = subject

        if self._config.cc_emails:
            msg["Cc"] = ", ".join(self._config.cc_emails)

        # Attach HTML body
        alternative = MIMEMultipart("alternative")
        alternative.attach(MIMEText(html_body, "html", "utf-8"))
        msg.attach(alternative)

        # Attach files
        if attachments:
            for attachment_path in attachments:
                if attachment_path and attachment_path.exists():
                    self._attach_file(msg, attachment_path)
                else:
                    logger.warning(f"⚠️  Attachment not found: {attachment_path}")

        return msg

    def _attach_file(self, msg: MIMEMultipart, file_path: Path) -> None:
        """Attach a file to the email message."""
        mime_type, _ = mimetypes.guess_type(str(file_path))
        if mime_type is None:
            mime_type = "application/octet-stream"

        main_type, sub_type = mime_type.split("/", 1)

        with open(file_path, "rb") as f:
            attachment = MIMEBase(main_type, sub_type)
            attachment.set_payload(f.read())

        encoders.encode_base64(attachment)
        attachment.add_header(
            "Content-Disposition",
            "attachment",
            filename=file_path.name,
        )
        msg.attach(attachment)
        logger.info(f"📎 Attached: {file_path.name} ({file_path.stat().st_size / 1024:.1f} KB)")

    # ------------------------------------------------------------------
    # SMTP Sending
    # ------------------------------------------------------------------

    def _send_smtp(self, msg: MIMEMultipart) -> bool:
        """Send the email via SMTP with STARTTLS."""
        all_recipients = self._config.to_emails + self._config.cc_emails

        try:
            logger.info(
                f"📡 Connecting to SMTP [{self._config.smtp_server}:{self._config.smtp_port}]"
            )
            with smtplib.SMTP(self._config.smtp_server, self._config.smtp_port, timeout=30) as server:
                server.ehlo()

                if self._config.use_tls:
                    server.starttls()
                    server.ehlo()

                server.login(self._config.email_user, self._config.email_password)
                server.sendmail(
                    self._config.email_user,
                    all_recipients,
                    msg.as_string(),
                )

            logger.info(
                f"✅ Email sent successfully to {len(all_recipients)} recipient(s)."
            )
            return True

        except smtplib.SMTPAuthenticationError as exc:
            logger.error(f"❌ SMTP Authentication failed: {exc}")
            raise EmailError(f"Authentication failed: {exc}") from exc
        except smtplib.SMTPRecipientsRefused as exc:
            logger.error(f"❌ Recipients refused: {exc}")
            raise EmailError(f"Recipients refused: {exc}") from exc
        except smtplib.SMTPException as exc:
            logger.error(f"❌ SMTP error: {exc}")
            raise EmailError(f"SMTP error: {exc}") from exc
        except OSError as exc:
            logger.error(f"❌ Network error connecting to SMTP server: {exc}")
            raise EmailError(f"Network error: {exc}") from exc

    # ------------------------------------------------------------------
    # HTML Body Builder
    # ------------------------------------------------------------------

    def _build_html_body(
        self,
        report_date: str,
        formatted_date: str,
        html_preview: str,
        row_count: int,
        attachments: List[Path],
        test_mode: bool,
        template_path: Optional[Path],
        extra_context: dict,
    ) -> str:
        """
        Build the HTML email body from template or fallback inline template.

        Args:
            report_date: ISO date string.
            formatted_date: Human-readable date string.
            html_preview: HTML table of report data.
            row_count: Total records in the report.
            attachments: List of attachment paths.
            template_path: Path to external HTML template file.
            extra_context: Additional template variables.

        Returns:
            Rendered HTML string.
        """
        if template_path and template_path.exists():
            template_html = template_path.read_text(encoding="utf-8")
        else:
            template_html = self._default_template()

        generated_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        company_name = (extra_context.get("company_name") or "").strip()
        safe_company_name = escape(company_name)
        report_title = "Daily Attendance &amp; Leave Report"
        company_report_title = (
            f"{safe_company_name} {report_title}"
            if safe_company_name else report_title
        )

        if row_count == 0:
            message_body = (
                f"<strong>{company_report_title}</strong> for "
                f"<strong>{formatted_date}</strong> has been automatically generated "
                f"and contains <strong>0</strong> employee record(s). "
                f"All employees were present. No attachment is included."
            )
            attachment_section = ""
        else:
            message_body = (
                f"Please find attached the <strong>{company_report_title}</strong> "
                f"for <strong>{formatted_date}</strong>. The report has been automatically "
                f"generated and contains <strong>{row_count}</strong> employee record(s)."
            )
            attachment_section = (
                '<p style="font-size:13px; color:#333; margin:20px 0 4px;">'
                '📎 <strong>Attachment Included</strong></p>'
                '<p style="font-size:12px; color:#555; margin:0 0 24px; line-height:1.5;">'
                'The report is attached as a <strong>PDF</strong> file.</p>'
            )

        test_banner = ""
        if test_mode:
            test_banner = """
            <tr>
              <td style="background:#FFEBEE; padding:10px 40px; text-align:center; border-bottom:2px solid #FFCDD2;">
                <p style="margin:0; font-size:14px; font-weight:bold; color:#D32F2F;">
                  ⚠️ TEST REPORT — DO NOT TAKE ACTION
                </p>
              </td>
            </tr>
            """

        return (
            template_html
            .replace("{{MESSAGE_BODY}}", message_body)
            .replace("{{REPORT_DATE}}", report_date)
            .replace("{{FORMATTED_DATE}}", formatted_date)
            .replace("{{ROW_COUNT}}", str(row_count))
            .replace("{{GENERATED_AT}}", generated_at)
            .replace("{{HTML_PREVIEW}}", html_preview)
            .replace("{{SENDER_NAME}}", extra_context.get("sender_name", "HR System"))
            .replace("{{COMPANY_NAME}}", safe_company_name or "HR Department")
            .replace("{{ATTACHMENT_SECTION}}", attachment_section)
            .replace("{{TEST_MODE_BANNER}}", test_banner)
        )

    @staticmethod
    def _default_template() -> str:
        """Fallback inline HTML template (used if template file not found)."""
        return """<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Daily Attendance Leave Report</title></head>
<body style="margin:0;padding:0;background:#f0f4f8;font-family:Calibri,Arial,sans-serif;">
<table width="100%" cellpadding="0" cellspacing="0" style="background:#f0f4f8;padding:24px 0;">
  <tr><td align="center">
    <table width="680" cellpadding="0" cellspacing="0"
           style="background:#ffffff;border-radius:10px;overflow:hidden;
                  box-shadow:0 4px 20px rgba(0,0,0,0.08);">

      <!-- Header Banner -->
      <tr><td style="background:linear-gradient(135deg,#1F3864 0%,#2E4F8A 100%);
                     padding:28px 36px;text-align:center;">
        <h1 style="color:#fff;margin:0;font-size:22px;letter-spacing:1px;">
          📊 HR DAILY ATTENDANCE &amp; LEAVE REPORT
        </h1>
        <p style="color:#a8c0e8;margin:6px 0 0;font-size:13px;">
          Report Date: <strong style="color:#fff;">{{FORMATTED_DATE}}</strong>
        </p>
      </td></tr>

      <!-- Body -->
      <tr><td style="padding:28px 36px;">

        <p style="font-size:14px;color:#333;line-height:1.6;margin:0 0 16px;">
          Dear Team,
        </p>
        <p style="font-size:14px;color:#333;line-height:1.6;margin:0 0 20px;">
          Please find attached the <strong>Daily Attendance &amp; Leave Report</strong>
          for <strong>{{FORMATTED_DATE}}</strong>. The report contains
          <strong>{{ROW_COUNT}}</strong> employee record(s).
        </p>

        <!-- Stats Cards -->
        <table width="100%" cellpadding="0" cellspacing="0" style="margin:0 0 20px;">
          <tr>
            <td width="33%" style="padding:4px;">
              <div style="background:#EBF0FA;border-radius:8px;padding:14px;text-align:center;
                          border-left:4px solid #1F3864;">
                <div style="font-size:22px;font-weight:bold;color:#1F3864;">{{ROW_COUNT}}</div>
                <div style="font-size:11px;color:#666;margin-top:4px;">Total Records</div>
              </div>
            </td>
            <td width="33%" style="padding:4px;">
              <div style="background:#EBF0FA;border-radius:8px;padding:14px;text-align:center;
                          border-left:4px solid #2E7D32;">
                <div style="font-size:22px;font-weight:bold;color:#2E7D32;">{{FORMATTED_DATE}}</div>
                <div style="font-size:11px;color:#666;margin-top:4px;">Report Date</div>
              </div>
            </td>
            <td width="33%" style="padding:4px;">
              <div style="background:#EBF0FA;border-radius:8px;padding:14px;text-align:center;
                          border-left:4px solid #E65100;">
                <div style="font-size:14px;font-weight:bold;color:#E65100;">{{GENERATED_AT}}</div>
                <div style="font-size:11px;color:#666;margin-top:4px;">Generated At</div>
              </div>
            </td>
          </tr>
        </table>

        <!-- Report Preview -->
        {{HTML_PREVIEW}}

        <!-- Instruction -->
        <div style="background:#F8F9FA;border-radius:6px;padding:14px 18px;
                    border:1px solid #DEE2E6;margin:20px 0;">
          <p style="margin:0;font-size:12px;color:#555;">
            📎 <strong>Attachment:</strong> The complete report is attached.
            Please open the file for full details, filtering, and analysis capabilities.
          </p>
        </div>

        <p style="font-size:13px;color:#444;margin:20px 0 4px;">Best regards,</p>
        <p style="font-size:14px;font-weight:bold;color:#1F3864;margin:0;">{{SENDER_NAME}}</p>
        <p style="font-size:12px;color:#888;margin:4px 0 0;">{{COMPANY_NAME}}</p>

      </td></tr>

      <!-- Footer -->
      <tr><td style="background:#1F3864;padding:16px 36px;text-align:center;">
        <p style="color:#7fa3c8;font-size:11px;margin:0;">
          This is an automated report generated by the HR Attendance System.
          Please do not reply directly to this email.
        </p>
      </td></tr>
    </table>
  </td></tr>
</table>
</body></html>"""
