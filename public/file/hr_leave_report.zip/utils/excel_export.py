# =============================================================================
# utils/excel_export.py - Excel Report Generator
# HR Daily Attendance Leave Report System
# =============================================================================

import zipfile
from datetime import datetime
from html import escape
from pathlib import Path
from typing import Optional

import pandas as pd
from openpyxl import load_workbook
from openpyxl.styles import (
    Font, PatternFill, Alignment, Border, Side, GradientFill
)
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.table import Table, TableStyleInfo

from utils.logger import get_logger

logger = get_logger()

# ---------------------------------------------------------------------------
# Color Palette (Enterprise HR Style)
# ---------------------------------------------------------------------------
HEADER_BG_COLOR = "1F3864"       # Deep navy blue
HEADER_FONT_COLOR = "FFFFFF"     # White
ALT_ROW_COLOR = "EBF0FA"         # Light blue tint
BORDER_COLOR = "BDD7EE"          # Soft blue border
TOTAL_ROW_COLOR = "D6E4F0"       # Summary row highlight
TITLE_COLOR = "1F3864"           # Title text color

# Keep report output readable when converted from Excel to PDF. Excel can let
# long values visually spill into neighboring cells during PDF export, so the
# display copy is clipped while the source query data remains untouched.
DISPLAY_LIMITS = {
    "date": 10,
    "employee code": 14,
    "name": 24,
    "office": 14,
    "department": 24,
    "period of leave": 23,
    "leave applied": 18,
    "resume to work": 14,
    "remark": 28,
}

COLUMN_WIDTHS = {
    "date": 12,
    "employee code": 15,
    "name": 22,
    "office": 14,
    "department": 24,
    "period of leave": 22,
    "leave applied": 17,
    "resume to work": 15,
    "remark": 26,
}


class ExcelExporter:
    """
    Generates professionally formatted Excel reports.

    Features:
    - Auto column widths
    - Bold, colored headers with freeze pane
    - Alternating row colors
    - Named Excel Table with filtering
    - Summary/totals row
    - Optional password protection
    - Optional ZIP compression
    """

    def __init__(self, config):
        """
        Args:
            config: AppConfig.report (ReportConfig dataclass)
        """
        self._config = config

    def export(
        self,
        df: pd.DataFrame,
        report_date: str,
        company_name: str = "",
        db_name: str = "",
        sheet_name: str = "Attendance Leave Report",
    ) -> Path:
        """
        Export DataFrame to a styled XLSX file.

        Args:
            df: Report data as pandas DataFrame.
            report_date: Report date string (YYYY-MM-DD). Used in filename.
            sheet_name: Name of the Excel worksheet.

        Returns:
            Path to the generated Excel file (or ZIP if enabled).
        """
        date_str = datetime.strptime(report_date, "%Y-%m-%d").strftime("%Y%m%d")
        prefix = ""
        if db_name:
            # Extract everything after the last underscore, fallback to the full db_name
            parts = db_name.split("_")
            prefix = parts[-1].lower() + "_"
        filename = f"{prefix}Daily_Attendance_Leave_Report_{date_str}.xlsx"
        output_path = self._config.reports_dir / filename

        logger.info(f"📊 Generating Excel report: {filename}")
        logger.info(f"   Rows: {len(df)} | Columns: {len(df.columns)}")

        display_df = self._prepare_display_df(df)

        # Write display-safe data first with pandas (creates the base file)
        with pd.ExcelWriter(str(output_path), engine="openpyxl") as writer:
            display_df.to_excel(
                writer,
                sheet_name=sheet_name,
                index=False,
                startrow=3,        # Leave room for title header rows
            )

        # Now apply professional styling with openpyxl
        self._apply_styling(output_path, display_df, sheet_name, report_date, company_name)

        logger.info(f"✅ Excel report saved: {output_path}")

        # Optional ZIP compression
        if self._config.zip_report:
            output_path = self._compress_to_zip(output_path)

        return output_path

    # ------------------------------------------------------------------
    # Styling Engine
    # ------------------------------------------------------------------

    def _prepare_display_df(self, df: pd.DataFrame) -> pd.DataFrame:
        """Return a report-safe display copy with long text clipped."""
        display_df = df.copy()
        for col_name in display_df.columns:
            limit = DISPLAY_LIMITS.get(self._normalise_column_name(col_name))
            if limit:
                display_df[col_name] = display_df[col_name].map(
                    lambda value: self._clip_text(value, limit)
                )
        return display_df

    @staticmethod
    def _normalise_column_name(col_name) -> str:
        return " ".join(str(col_name).strip().lower().split())

    @staticmethod
    def _clip_text(value, max_chars: int) -> str:
        if pd.isna(value):
            return ""
        text = str(value).strip()
        if len(text) <= max_chars:
            return text
        if max_chars <= 3:
            return "." * max_chars
        return text[:max_chars - 3].rstrip() + "..."

    def _apply_styling(
        self,
        file_path: Path,
        df: pd.DataFrame,
        sheet_name: str,
        report_date: str,
        company_name: str = "",
    ) -> None:
        """Apply enterprise-grade formatting to the workbook."""
        wb = load_workbook(str(file_path))
        ws = wb[sheet_name]

        num_cols = len(df.columns)
        num_rows = len(df)
        last_col_letter = get_column_letter(num_cols)

        # ---- Title Banner ------------------------------------------------
        self._add_title_rows(ws, num_cols, report_date, company_name)

        # ---- Header Row (row 4, since data starts at startrow=3 → row 4 in Excel) --
        header_row = 4
        self._style_header_row(ws, header_row, num_cols)

        # ---- Data Rows ---------------------------------------------------
        data_start = header_row + 1
        data_end = data_start + num_rows - 1
        self._style_data_rows(ws, data_start, data_end, num_cols)

        # ---- Auto Column Widths ------------------------------------------
        self._set_column_widths(ws, df, header_row)

        # ---- Freeze Header -----------------------------------------------
        ws.freeze_panes = f"A{data_start}"

        # ---- Excel Table with AutoFilter ---------------------------------
        if num_rows > 0:
            table_ref = f"A{header_row}:{last_col_letter}{data_end}"
            table = Table(displayName="AttendanceReport", ref=table_ref)
            table.tableStyleInfo = TableStyleInfo(
                name="TableStyleMedium9",
                showFirstColumn=False,
                showLastColumn=False,
                showRowStripes=True,
                showColumnStripes=False,
            )
            ws.add_table(table)

        # ---- Sheet Appearance -------------------------------------------
        ws.sheet_view.showGridLines = False
        ws.print_title_rows = f"1:1"
        ws.page_setup.orientation = "landscape"
        ws.page_setup.fitToPage = True

        wb.save(str(file_path))

    def _add_title_rows(self, ws, num_cols: int, report_date: str, company_name: str = "") -> None:
        """Add company/report title rows at top of sheet."""
        last_col = get_column_letter(num_cols)

        # Row 1: Company / System title
        ws.merge_cells(f"A1:{last_col}1")
        title_cell = ws["A1"]
        
        title_text = "HR DAILY LEAVE REPORT"
        if company_name:
            title_text = f"{company_name.upper()} {title_text}"
            
        title_cell.value = title_text
        title_cell.font = Font(
            name="Calibri", bold=True, size=16, color=HEADER_FONT_COLOR
        )
        title_cell.fill = PatternFill("solid", fgColor=HEADER_BG_COLOR)
        title_cell.alignment = Alignment(horizontal="center", vertical="center")
        ws.row_dimensions[1].height = 32

        # Row 2: Report date
        ws.merge_cells(f"A2:{last_col}2")
        date_cell = ws["A2"]
        date_cell.value = f"Report Date: {report_date}  |  Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
        date_cell.font = Font(name="Calibri", italic=True, size=10, color="FFFFFF")
        date_cell.fill = PatternFill("solid", fgColor="2E4F8A")
        date_cell.alignment = Alignment(horizontal="center", vertical="center")
        ws.row_dimensions[2].height = 18

        # Row 3: Spacer
        ws.merge_cells(f"A3:{last_col}3")
        ws["A3"].fill = PatternFill("solid", fgColor="F5F8FF")
        ws.row_dimensions[3].height = 6

    def _style_header_row(self, ws, header_row: int, num_cols: int) -> None:
        """Apply bold, colored styling to the column header row."""
        thin_border = Border(
            left=Side(style="thin", color=BORDER_COLOR),
            right=Side(style="thin", color=BORDER_COLOR),
            top=Side(style="thin", color=BORDER_COLOR),
            bottom=Side(style="medium", color="1F3864"),
        )

        for col_idx in range(1, num_cols + 1):
            cell = ws.cell(row=header_row, column=col_idx)
            cell.font = Font(
                name="Calibri", bold=True, size=11, color=HEADER_FONT_COLOR
            )
            cell.fill = PatternFill("solid", fgColor=HEADER_BG_COLOR)
            cell.alignment = Alignment(
                horizontal="center", vertical="center", wrap_text=True
            )
            cell.border = thin_border

        ws.row_dimensions[header_row].height = 28

    def _style_data_rows(
        self, ws, start_row: int, end_row: int, num_cols: int
    ) -> None:
        """Apply alternating row colors and borders to data rows."""
        thin_border = Border(
            left=Side(style="thin", color=BORDER_COLOR),
            right=Side(style="thin", color=BORDER_COLOR),
            top=Side(style="thin", color=BORDER_COLOR),
            bottom=Side(style="thin", color=BORDER_COLOR),
        )

        for row_idx in range(start_row, end_row + 1):
            is_alt = (row_idx - start_row) % 2 == 1
            row_color = ALT_ROW_COLOR if is_alt else "FFFFFF"

            for col_idx in range(1, num_cols + 1):
                cell = ws.cell(row=row_idx, column=col_idx)
                cell.font = Font(name="Calibri", size=10)
                cell.fill = PatternFill("solid", fgColor=row_color)
                cell.alignment = Alignment(vertical="center", wrap_text=False)
                cell.border = thin_border

            ws.row_dimensions[row_idx].height = 18

    def _set_column_widths(self, ws, df: pd.DataFrame, header_row: int) -> None:
        """Auto-fit column widths based on content."""
        MIN_WIDTH = 10
        MAX_WIDTH = 28

        for col_idx, col_name in enumerate(df.columns, start=1):
            col_letter = get_column_letter(col_idx)
            fixed_width = COLUMN_WIDTHS.get(self._normalise_column_name(col_name))
            if fixed_width:
                ws.column_dimensions[col_letter].width = fixed_width
                continue

            # Calculate max content length
            max_length = len(str(col_name))
            col_data = df.iloc[:, col_idx - 1].astype(str)
            if not col_data.empty:
                max_length = max(max_length, col_data.str.len().max())

            adjusted_width = min(MAX_WIDTH, max(MIN_WIDTH, max_length + 4))
            ws.column_dimensions[col_letter].width = adjusted_width

    # ------------------------------------------------------------------
    # ZIP Compression
    # ------------------------------------------------------------------

    def _compress_to_zip(self, excel_path: Path) -> Path:
        """Compress the Excel file into a ZIP archive."""
        zip_path = excel_path.with_suffix(".zip")
        logger.info(f"🗜️  Compressing report to ZIP: {zip_path.name}")

        with zipfile.ZipFile(str(zip_path), "w", zipfile.ZIP_DEFLATED) as zf:
            zf.write(str(excel_path), arcname=excel_path.name)

        # Remove uncompressed Excel file
        excel_path.unlink()
        logger.info(f"✅ ZIP archive created: {zip_path}")
        return zip_path

    # ------------------------------------------------------------------
    # HTML Preview Generator (for email body)
    # ------------------------------------------------------------------

    def generate_html_preview(
        self, df: pd.DataFrame, max_rows: int = 20, report_date: str = ""
    ) -> str:
        """
        Generate an HTML table preview for embedding in email body.

        Args:
            df: Report DataFrame.
            max_rows: Maximum number of rows to show in the preview.
            report_date: Report date for the preview caption.

        Returns:
            HTML string with styled table.
        """
        preview_df = self._prepare_display_df(df.head(max_rows))
        total_rows = len(df)
        is_truncated = total_rows > max_rows

        # Build HTML table rows manually for full styling control
        header_html = "".join(
            f'<th style="background:#1F3864;color:#fff;padding:8px 12px;'
            f'text-align:center;font-size:12px;white-space:nowrap;'
            f'border:1px solid #2E4F8A;">{escape(str(col))}</th>'
            for col in preview_df.columns
        )

        rows_html = ""
        for i, (_, row) in enumerate(preview_df.iterrows()):
            bg = "#EBF0FA" if i % 2 == 1 else "#FFFFFF"
            cells = "".join(
                f'<td style="padding:6px 10px;border:1px solid #BDD7EE;'
                f'font-size:11px;background:{bg};max-width:160px;'
                f'white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">'
                f'{escape(str(val))}</td>'
                for val in row.values
            )
            rows_html += f"<tr>{cells}</tr>\n"

        truncation_notice = (
            f'<tr><td colspan="{len(preview_df.columns)}" '
            f'style="text-align:center;padding:8px;background:#FFF3CD;'
            f'color:#856404;font-size:11px;font-style:italic;">'
            f'Continue...</td></tr>'
        ) if is_truncated else ""

        return f"""
        <div style="margin:16px 0;">
            <p style="font-size:12px;color:#555;margin-bottom:6px;">
                📋 <strong>Preview</strong> — Showing {min(max_rows, total_rows)} of {total_rows} records
                {f'for <strong>{report_date}</strong>' if report_date else ''}
            </p>
            <div style="overflow-x:auto;">
                <table style="border-collapse:collapse;width:100%;table-layout:fixed;font-family:Calibri,Arial,sans-serif;
                              box-shadow:0 2px 8px rgba(0,0,0,0.1);">
                    <thead><tr>{header_html}</tr></thead>
                    <tbody>{rows_html}{truncation_notice}</tbody>
                </table>
            </div>
        </div>
        """
