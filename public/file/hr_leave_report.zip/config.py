# =============================================================================
# config.py - Centralized Configuration Manager
# HR Daily Attendance Leave Report System
# =============================================================================

import os
from dataclasses import dataclass, field
from typing import List, Optional
from pathlib import Path
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

# Project root directory
BASE_DIR = Path(__file__).parent.resolve()
REPORTS_DIR = BASE_DIR / "reports"
LOGS_DIR = BASE_DIR / "logs"
TEMPLATES_DIR = BASE_DIR / "templates"

# Ensure directories exist
REPORTS_DIR.mkdir(exist_ok=True)
LOGS_DIR.mkdir(exist_ok=True)


# =============================================================================
# Database Configuration
# =============================================================================

@dataclass
class DatabaseConfig:
    """SQL Server connection settings."""
    server: str = field(default_factory=lambda: os.getenv("SQL_SERVER", ""))
    database: str = field(default_factory=lambda: os.getenv("SQL_DATABASE", "")) # Overridable
    username: str = field(default_factory=lambda: os.getenv("SQL_USERNAME", ""))
    password: str = field(default_factory=lambda: os.getenv("SQL_PASSWORD", ""))
    config_database: str = field(default_factory=lambda: os.getenv("SQL_CONFIG_DATABASE", "HR_REPORT_CONFIG"))
    driver: str = field(default_factory=lambda: os.getenv("SQL_DRIVER", "ODBC Driver 17 for SQL Server"))
    auth_mode: str = field(default_factory=lambda: os.getenv("SQL_AUTH_MODE", "sql"))
    retry_attempts: int = field(default_factory=lambda: int(os.getenv("SQL_RETRY_ATTEMPTS", "3")))
    retry_delay: int = field(default_factory=lambda: int(os.getenv("SQL_RETRY_DELAY", "5")))

    @property
    def connection_string(self) -> str:
        """Build the pyodbc connection string based on auth mode."""
        base = (
            f"DRIVER={{{self.driver}}};"
            f"SERVER={self.server};"
            f"DATABASE={self.database};"
        )
        if self.auth_mode.lower() == "windows":
            return base + "Trusted_Connection=yes;"
        else:
            return base + f"UID={self.username};PWD={self.password};"

    def validate(self) -> None:
        """Raise ValueError if required fields are missing."""
        if not self.server:
            raise ValueError("SQL_SERVER is not configured in .env")
        if self.auth_mode.lower() == "sql":
            if not self.username:
                raise ValueError("SQL_USERNAME is required for SQL authentication")
            if not self.password:
                raise ValueError("SQL_PASSWORD is required for SQL authentication")


# =============================================================================
# Email / SMTP Configuration
# =============================================================================

@dataclass
class EmailConfig:
    """SMTP email settings."""
    smtp_server: str = field(default_factory=str)
    smtp_port: int = field(default_factory=int)
    email_user: str = field(default_factory=str)
    email_password: str = field(default_factory=str)
    use_tls: bool = field(default_factory=bool)
    to_emails: List[str] = field(default_factory=list)
    cc_emails: List[str] = field(default_factory=list)

    def validate(self) -> None:
        """Raise ValueError if required fields are missing."""
        if not self.smtp_server:
            raise ValueError("SMTP Server is not configured.")
        if not self.email_user:
            raise ValueError("EMAIL_USER is not configured.")
        if not self.email_password:
            raise ValueError("EMAIL_PASSWORD is not configured.")


# =============================================================================
# Report Configuration
# =============================================================================

@dataclass
class ReportTarget:
    """Represents a database target fetched from config DB."""
    database_name: str
    display_name: str
    smtp_server: str
    smtp_port: int
    email_user: str
    email_password: str
    email_use_tls: bool
    to_emails: List[str]
    cc_emails: List[str]


@dataclass
class ReportConfig:
    """Report generation settings."""
    default_report_date: str = field(
        default_factory=lambda: os.getenv("DEFAULT_REPORT_DATE", "")
    )
    filter_department: Optional[str] = field(
        default_factory=lambda: os.getenv("FILTER_DEPARTMENT") or None
    )
    filter_branch: Optional[str] = field(
        default_factory=lambda: os.getenv("FILTER_BRANCH") or None
    )
    excel_password: Optional[str] = field(
        default_factory=lambda: os.getenv("EXCEL_PASSWORD") or None
    )
    zip_report: bool = field(
        default_factory=lambda: os.getenv("ZIP_REPORT", "False").lower() == "true"
    )
    email_preview_rows: int = field(
        default_factory=lambda: int(os.getenv("EMAIL_PREVIEW_ROWS", "20"))
    )
    reports_dir: Path = REPORTS_DIR


# =============================================================================
# Scheduler Configuration
# =============================================================================

@dataclass
class SchedulerConfig:
    """Job scheduler settings."""
    schedule_time: str = field(
        default_factory=lambda: os.getenv("SCHEDULE_TIME", "07:00")
    )
    timezone: str = field(
        default_factory=lambda: os.getenv("TIMEZONE", "Asia/Kuala_Lumpur")
    )


# =============================================================================
# Logging Configuration
# =============================================================================

@dataclass
class LoggingConfig:
    """Application logging settings."""
    log_level: str = field(
        default_factory=lambda: os.getenv("LOG_LEVEL", "INFO").upper()
    )
    retention_days: int = field(
        default_factory=lambda: int(os.getenv("LOG_RETENTION_DAYS", "30"))
    )
    logs_dir: Path = LOGS_DIR


# =============================================================================
# Notification Configuration
# =============================================================================

@dataclass
class NotificationConfig:
    """Optional notification integrations (Teams, Telegram)."""
    teams_webhook_url: Optional[str] = field(
        default_factory=lambda: os.getenv("TEAMS_WEBHOOK_URL") or None
    )
    telegram_bot_token: Optional[str] = field(
        default_factory=lambda: os.getenv("TELEGRAM_BOT_TOKEN") or None
    )
    telegram_chat_id: Optional[str] = field(
        default_factory=lambda: os.getenv("TELEGRAM_CHAT_ID") or None
    )

    @property
    def teams_enabled(self) -> bool:
        return bool(self.teams_webhook_url)

    @property
    def telegram_enabled(self) -> bool:
        return bool(self.telegram_bot_token and self.telegram_chat_id)


# =============================================================================
# Aggregate App Configuration
# =============================================================================

class AppConfig:
    """
    Single entry point for all application configuration.
    Usage:
        from config import AppConfig
        cfg = AppConfig()
        print(cfg.db.server)
    """

    def __init__(self):
        self.db = DatabaseConfig()
        self.email = EmailConfig()
        self.report = ReportConfig()
        self.scheduler = SchedulerConfig()
        self.logging = LoggingConfig()
        self.notifications = NotificationConfig()

    def validate_all(self) -> None:
        """Validate global configuration values."""
        self.db.validate()

    def __repr__(self) -> str:
        return (
            f"AppConfig("
            f"server={self.db.server}, "
            f"database={self.db.database}, "
            f"smtp={self.email.smtp_server}:{self.email.smtp_port}, "
            f"schedule={self.scheduler.schedule_time}"
            f")"
        )
